Sanitized evidence for CNTRLPLANE-4338. This is execution evidence, not a portable provisioning kit.
Before/after source revisions, versions, image digests, timestamps, values, conditions and test outcomes are retained.
Operator names, local paths, live identifiers, IP addresses and cluster endpoints are replaced consistently.
Kubernetes managedFields and last-applied annotations are omitted. Private originals remain outside this archive.
No Secrets, kubeconfigs, private keys, AWS session files or CSRs are selected. Discarded/corrupt watch attempts are excluded.
Reproduction scripts require authorized credentials and local paths to be configured; do not run them as report readers.
Go sources under source/hypershift-pr and source/hypershift-baseline are transformed evidence copies, not executable overlays. Their upstream hostname literals may have changed. source/replay-manifest.json records both original and transformed hashes. Use reproduction/restore_unit_sources.py --head-checkout /path/to/pinned-head --output /path/to/new-output to reconstruct and verify exact original head and retrospective baseline tests from public upstream source.
Large JSONL streams are split at record boundaries into ordered parts under 4 MiB. chunk-index.json records reassembly order and complete sanitized stream hashes; every observation in each retained stream is preserved. Discarded/corrupt watch attempts remain excluded as disclosed above.
A sanitized copy of the supplied plan is retained as source/test-plan.txt. Public CI citations are preserved; source/plan-provenance.json identifies the pinned original. Upstream plan-v4 validator incompatibilities are reported separately.
All previously published artifact paths remain in this ZIP. Original creation metadata is unchanged; evidence/provenance/creation-metadata-clarification.json identifies stale descriptive release labels and the authoritative release captures.
