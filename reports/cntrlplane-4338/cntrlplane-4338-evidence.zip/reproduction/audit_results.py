#!/usr/bin/env python3
"""Independently verify completion snapshots and clean final source-watch captures."""
import datetime as dt
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MAIN = ROOT / "private/live/hc-4338-main"
UPGRADE = ROOT / "private/live/hc-4338-upgrade"


def read(p):
    return json.loads(p.read_text())


def parse_stream(p):
    text = p.read_text()
    assert "\x00" not in text, "Corrupt source watch"
    rows = []
    decoder = json.JSONDecoder()
    while text.strip():
        item, end = decoder.raw_decode(text.lstrip())
        rows.append(item)
        text = text.lstrip()[end:]
    return rows


def main():
    checks = []
    initial = json.loads((MAIN / "main-tests/full-readiness-before-mutations/readiness.jsonl").read_text().splitlines()[-1])
    expected_operators = {o["metadata"]["name"] for o in initial["operators"]["items"]}
    expected_components = {c["metadata"]["name"] for c in initial["components"]["items"]}
    target_version = initial["clusterversion"]["status"]["desired"]["version"]
    for lifecycle in ["main-lifecycle", "upgrade-lifecycle"]:
        rows = [json.loads(line) for line in (ROOT / "private" / lifecycle / "observations.jsonl").read_text().splitlines() if line]
        identities = {row["hc"]["metadata"]["uid"] for row in rows if isinstance(row.get("hc"), dict) and "metadata" in row["hc"]}
        assert len(identities) == 1, "Lifecycle observations mixed HC identities"
        versions = {row["guest_version"].get("status", {}).get("desired", {}).get("version") for row in rows
                    if isinstance(row.get("guest_version"), dict) and "metadata" in row["guest_version"]} - {None}
        assert not any(version.startswith("4.") for version in versions)
        checks.append({"lifecycle": lifecycle, "observation_count": len(rows), "distinct_hc_uid_count": len(identities),
                       "observed_guest_versions": sorted(versions), "excluded_old_release_bootstrap_attempts": True})
    baseline = read(MAIN / "TC-CA-001/before/configuration.json")["guest_image"]["spec"]
    for phase in ["sources-created", "selected-a", "selected-b", "reference-removed", "restored-before-source-cleanup", "final"]:
        state = read(MAIN / "TC-CA-001" / phase / "ca-projections.json")
        unchanged = state["guest_image"]["spec"] == baseline
        assert unchanged, phase + " changed unrelated image spec"
        checks.append({"phase": "TC-CA-001/" + phase, "unrelated_image_spec_unchanged": unchanged})
    final_ca = read(MAIN / "TC-CA-001/final/ca-projections.json")
    assert final_ca["user_ca"] is None
    assert all(copy is None for copies in final_ca["sources"].values() for copy in copies.values())
    assert not final_ca["guest_proxy"]["spec"].get("trustedCA", {}).get("name")
    checks.append({"phase": "TC-CA-001/final", "all_test_source_and_destination_copies_absent": True,
                   "user_ca_absent": True, "guest_custom_trust_reference_removed": True})
    for root, phases in [(MAIN, ["TC-CA-001/selected-a", "TC-CA-001/selected-b", "TC-CA-001/reference-removed", "TC-CA-001/restored",
                                 "TC-REG-007A/update-1", "TC-REG-007A/update-2", "TC-REG-007A/restored", "main-tests/final-restored-readiness",
                                 "main-tests/final-delivery-readiness"]),
                         (UPGRADE, ["TC-REG-007B/healthy-previous-release-before-pr", "TC-REG-007B/upgrade-complete"])]:
        for phase in phases:
            completion = read(root / phase / "readiness-complete.json")
            row = json.loads((root / phase / "readiness.jsonl").read_text().splitlines()[-1])
            ready = [n for n in row["nodes"]["items"] if not n["metadata"].get("deletionTimestamp")
                     and any(c["type"] == "Ready" and c["status"] == "True" for c in n["status"]["conditions"])]
            expected = sum(p["spec"]["replicas"] for p in row["nodepools"])
            assert len(ready) == expected == 2
            conditions = {c["type"]: c for c in row["hcp"]["status"]["conditions"]}
            c = conditions["ConfigOperatorReconciliationSucceeded"]
            assert c["status"] == "True" and c["observedGeneration"] == row["hcp"]["metadata"]["generation"], phase
            components = row["components"]["items"]
            assert {c["metadata"]["name"] for c in components} == expected_components, phase
            if completion["version"] == target_version:
                assert {o["metadata"]["name"] for o in row["operators"]["items"]} == expected_operators, phase
            assert all(c["status"].get("version") == completion["version"]
                       and c["status"].get("observedGeneration") == row["hcp"]["metadata"]["generation"] for c in components), phase
            target = row["hc"]["spec"]["release"]["image"].split("@")[-1]
            cp_target = row["hc"]["spec"].get("controlPlaneRelease", {}).get("image", row["hc"]["spec"]["release"]["image"]).split("@")[-1]
            for status, desired in [(row["clusterversion"]["status"], target), (row["hc"]["status"]["version"], target),
                                    (row["hcp"]["status"]["controlPlaneVersion"], cp_target)]:
                assert status["desired"]["image"].split("@")[-1] == desired and status["history"][0]["image"].split("@")[-1] == desired, phase
            machines = [m for m in row["cluster_api"]["items"] if m["kind"] == "Machine" and not m["metadata"].get("deletionTimestamp")]
            assert len(machines) == 2 and all(m["status"]["phase"] == "Running" for m in machines), phase
            checks.append({"phase": phase, "completed_at": completion["completed_at"], "nonterminating_ready_nodes": len(ready),
                           "nonterminating_running_machines": len(machines), "fresh_hcco_reconciliation": True,
                           "control_plane_components": len(components), "component_versions_and_hcp_generations_match": True,
                           "guest_operator_count": len(row["operators"]["items"]), "expected_component_set_verified": True,
                           "operator_set_comparison": "matches healthy target-release reference" if completion["version"] == target_version else "previous release; later-release operator-set comparison omitted",
                           "immutable_payload_desired_and_history_match": True,
                           "config_hashes": completion["config_hashes"]})
    original = read(MAIN / "TC-REG-007A/before/configuration.json")
    final = read(MAIN / "TC-REG-007A/final/configuration.json")
    assert original["hc"]["spec"].get("configuration") == final["hc"]["spec"].get("configuration")
    assert original["guest_image"]["spec"].get("registrySources", {}).get("blockedRegistries", []) == final["guest_image"]["spec"].get("registrySources", {}).get("blockedRegistries", [])
    assert "verification.hypershift.openshift.io/cntrlplane-4338" not in final["guest_image"]["metadata"].get("annotations", {})
    checks.append({"phase": "TC-REG-007A/final", "original_hc_desired_configuration_restored": True,
                   "blocked_registries_equal_captured_baseline": True, "test_annotation_absent": True})
    baseline_hashes = read(MAIN / "TC-REG-007A/baseline-ready/readiness-complete.json")["config_hashes"]
    assert read(MAIN / "main-tests/final-delivery-readiness/readiness-complete.json")["config_hashes"] == baseline_hashes
    for kind, phase in [("build", "build-change"), ("project", "project-change")]:
        source = read(MAIN / "TC-PROP-001" / phase / "source-update.json")
        path = MAIN / "TC-PROP-001" / (("builds" if kind == "build" else "projects") + ".config.openshift.io-watch.json")
        events = parse_stream(path)
        matches = [e for e in events if e.get("type") == "MODIFIED" and e.get("object", {}).get("metadata", {}).get("resourceVersion") == source["metadata"]["resourceVersion"]]
        assert matches and any(e["object"].get("spec") == source.get("spec") for e in matches)
        checks.append({"source": kind, "source_resource_version": source["metadata"]["resourceVersion"], "clean_watch_event_count": len(events),
                       "matching_modified_event_captured": True, "hcco_trigger_causality": "blocked; identical empty requests and no source tracing"})
    output = {"audited_at": dt.datetime.now(dt.timezone.utc).isoformat(), "all_checks_passed": True, "checks": checks}
    (ROOT / "evidence/post-run-audit.json").write_text(json.dumps(output, indent=2))
    print("Independent post-run snapshot/watch audit passed:", len(checks), "checks.")


if __name__ == "__main__":
    main()
