#!/usr/bin/env python3
"""Build source-pinned CPO binaries without committing compiler caches to images."""
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
records = []
for flavor, revision in [
    ("pr", "d037aa90aa5b889c69464004df2e74f4c4c5b287"),
    ("baseline", "b0edc822e1ffb9f0527091a764d940b81b2c34a8"),
]:
    repo = root / "source" / ("hypershift-" + flavor)
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
    if actual != revision:
        raise SystemExit("Source revision does not match the pinned build")
    context = root / "private" / (flavor + "-image-context")
    context.mkdir(mode=0o700, exist_ok=True)
    env = dict(os.environ, GOOS="linux", GOARCH="amd64", CGO_ENABLED="0",
               GOWORK="off", GOFLAGS="-mod=vendor", GOMAXPROCS="4")
    linker = ("-s -w -X github.com/openshift/hypershift/support/supportedversion.commitHash="
              + revision)
    for binary in ["control-plane-operator", "control-plane-pki-operator"]:
        command = ["go", "build", "-p=4", "-trimpath", "-ldflags", linker,
                   "-o", str(context / binary), "./" + binary]
        print(flavor, "building", binary, flush=True)
        subprocess.run(command, cwd=repo, env=env, check=True)
    original = (repo / "Dockerfile.control-plane").read_text()
    labels = "\n".join(line for line in original.splitlines() if line.startswith("LABEL "))
    recipe = ("FROM registry.access.redhat.com/ubi9/ubi:latest\n"
              "COPY control-plane-operator /usr/bin/control-plane-operator\n"
              "COPY control-plane-pki-operator /usr/bin/control-plane-pki-operator\n"
              "ENTRYPOINT [\"/usr/bin/control-plane-operator\"]\n" + labels + "\n"
              + "LABEL io.openshift.build.commit.id=" + revision + "\n"
              + "LABEL io.openshift.build.source-location=https://github.com/openshift/hypershift\n")
    (context / "Dockerfile").write_text(recipe)
    tag = "quay.io/test-operator/hypershift:cntrlplane-4338-" + flavor + "-20261109"
    common = ["podman", "--connection", "podman-machine-default-root"]
    subprocess.run([*common, "build", "--platform", "linux/amd64", "--authfile",
                    "/work/operator/all-the-pull-secrets.json", "-t", tag, str(context)], check=True)
    digest_file = root / "private" / (flavor + "-push-digest.txt")
    subprocess.run([*common, "push", "--authfile", "/work/operator/.config/containers/auth.json",
                    "--digestfile", str(digest_file), tag], check=True)
    digest = digest_file.read_text().strip()
    records.append({"flavor": flavor, "source_revision": revision, "image_tag": tag,
                    "image_digest": digest, "image": tag.split(":")[0] + "@" + digest,
                    "build_environment": {k: env[k] for k in ["GOOS", "GOARCH", "CGO_ENABLED"]},
                    "note": "Only source-pinned binaries and original capability labels enter the runtime image."})
    (root / "private" / "built-images.json").write_text(json.dumps(records, indent=2))
    print(flavor, "image pushed", digest, flush=True)
