#!/bin/bash
# Create a Hosted Cluster on AWS using STS-based authentication
set -euo pipefail
umask 077
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export KUBECONFIG=/work/operator/aws_dev_kubeconfig
export AWS_SHARED_CREDENTIALS_FILE="${SCRIPT_DIR}/../private/aws-provisioning.ini"

# Configuration
PREFIX="test-operator"
HYPERSHIFT_BINARY_PATH="/work/operator/test-operator/hypershift_ws/hypershift/bin"
CLUSTER_NAME="hc-4338-main"
ROLE_NAME="${PREFIX}-hypershift-cli-role"
REGION="us-east-1"
BASE_DOMAIN="test.example.com"
STS_CREDS_FILE="${SCRIPT_DIR}/../private/aws-provisioning-sts.json"
PULL_SECRET="$HOME/all-the-pull-secrets.json"
NODE_POOL_REPLICAS=2
RELEASE_IMAGE=quay.io/openshift-release-dev/ocp-release-nightly@sha256:59840d558e55f4567d624c55564dcfff109a70de98d1f6ceabc81e3c229cf6ba
CPO_IMAGE=quay.io/test-operator/hypershift@sha256:e3f3c6a560d34155c708b2d78c38b9b261c2e3c2900f2b37023536643885d758

# Reuse the already running test HC without allocating another VPC.
existing_hc=$(oc get hostedcluster "${CLUSTER_NAME}" -n clusters --ignore-not-found -o name)
if [[ -n "${existing_hc}" ]]; then
  actual_release=$(oc get hostedcluster "${CLUSTER_NAME}" -n clusters -o jsonpath='{.spec.release.image}')
  actual_cpo=$(oc get hostedcluster "${CLUSTER_NAME}" -n clusters -o jsonpath='{.metadata.annotations.hypershift\.openshift\.io/control-plane-operator-image}')
  [[ "${actual_release}" == "${RELEASE_IMAGE}" ]]
  [[ "${actual_cpo}" == "${CPO_IMAGE}" ]]
  echo "Existing clusters/${CLUSTER_NAME} matches the pinned 5.1 payload and PR CPO image; using it."
  exit 0
fi

# Get existing role ARN
ROLE_ARN=$(aws iam get-role --role-name ${ROLE_NAME} --query "Role.Arn" --output text)

# Use the refreshed SAML STS session. GetSessionToken cannot refresh session credentials.
test -s "${STS_CREDS_FILE}"

# Create Hosted Cluster
${HYPERSHIFT_BINARY_PATH}/hypershift create cluster aws \
--name ${CLUSTER_NAME} \
--namespace clusters \
--node-pool-replicas ${NODE_POOL_REPLICAS} \
--base-domain ${BASE_DOMAIN} \
--pull-secret ${PULL_SECRET} \
--role-arn ${ROLE_ARN} \
--sts-creds ${STS_CREDS_FILE} \
--region ${REGION} \
--generate-ssh \
--release-image ${RELEASE_IMAGE} \
--control-plane-operator-image "${CPO_IMAGE}" \
--instance-type m5.xlarge \
--zones us-east-1a \
--single-nat-gateway \
--node-upgrade-type Replace \
--control-plane-availability-policy SingleReplica \
--infra-availability-policy SingleReplica 
