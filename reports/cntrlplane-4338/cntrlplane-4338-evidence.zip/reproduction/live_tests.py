#!/usr/bin/env python3
"""Execute serial live configuration cases and retain private empirical evidence."""
import argparse
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import yaml

ROOT = Path(__file__).resolve().parent
MGMT = "/work/operator/aws_dev_kubeconfig"
NS = "clusters"
PREFIX = "hypershift.openshift.io/"


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2))


def semantic_spec(value):
    """Normalize omitted Go zero values while retaining nonempty field values and list order."""
    if isinstance(value, dict):
        normalized = {key: semantic_spec(item) for key, item in value.items()}
        return {key: item for key, item in normalized.items() if item not in (None, "", False, 0, {}, [])}
    if isinstance(value, list):
        return [semantic_spec(item) for item in value]
    return value


class Run:
    def __init__(self, name, lifecycle):
        self.name = name
        self.cpns = NS + "-" + name
        self.guest = ROOT / "private" / lifecycle / "guest.kubeconfig"
        self.directory = ROOT / "private" / "live" / name
        self.directory.mkdir(parents=True, exist_ok=True)
        self.events = self.directory / "operations.jsonl"

    def oc(self, cluster, *args, optional=False, body=None):
        kubeconfig = MGMT if cluster == "management" else str(self.guest)
        command = ["oc", "--kubeconfig", kubeconfig, "--request-timeout=20s", *args]
        result = subprocess.run(command, input=json.dumps(body) if body is not None else None,
                                capture_output=True, text=True, timeout=35)
        with self.events.open("a") as stream:
            stream.write(json.dumps({"timestamp": now(), "cluster": cluster,
                                     "arguments": list(args), "body": body,
                                     "exit_code": result.returncode,
                                     "stderr": result.stderr}) + "\n")
        if result.returncode:
            if optional and "NotFound" in result.stderr:
                return None
            raise RuntimeError(result.stderr)
        if not result.stdout.strip():
            return None
        try:
            return json.loads(result.stdout)
        except ValueError:
            return result.stdout

    def get(self, cluster, resource, name=None, namespace=None, optional=False):
        args = ["get", resource]
        if name:
            args.append(name)
        if namespace:
            args += ["-n", namespace]
        return self.oc(cluster, *args, "-o", "json", optional=optional)

    def patch(self, cluster, resource, name, patch, namespace=None):
        args = ["patch", resource, name, "--type=merge", "-p", json.dumps(patch)]
        if namespace:
            args += ["-n", namespace]
        return self.oc(cluster, *args, "-o", "json")

    def save(self, phase, key, data):
        write(self.directory / phase / (key + ".json"), data)

    def wait(self, label, check, timeout=300, interval=5):
        deadline = time.monotonic() + timeout
        last_error = None
        while time.monotonic() < deadline:
            try:
                result = check()
                if result:
                    self.save("waits", label, {"completed_at": now(), "result": result})
                    return result
            except (RuntimeError, AssertionError) as error:
                last_error = str(error)
            time.sleep(interval)
        raise TimeoutError(label + ": " + str(last_error or "condition remained false"))

    def readiness(self, phase, version, previous_hashes=None, expected_hashes=None, timeout=2100):
        deadline = time.monotonic() + timeout
        records = self.directory / phase / "readiness.jsonl"
        records.parent.mkdir(parents=True, exist_ok=True)
        while time.monotonic() < deadline:
            try:
                hc = self.get("management", "hc", self.name, NS)
                hcp = self.get("management", "hcp", self.name, self.cpns)
                pools = [p for p in self.get("management", "np", namespace=NS)["items"]
                         if p["spec"]["clusterName"] == self.name]
                nodes = self.get("guest", "nodes")
                cv = self.get("guest", "clusterversion", "version")
                operators = self.get("guest", "clusteroperators")
                components = self.get("management", "controlplanecomponents", namespace=self.cpns)
                capi = self.get("management", "machinedeployments.cluster.x-k8s.io,machinesets.cluster.x-k8s.io,machines.cluster.x-k8s.io", namespace=self.cpns)
                row = {"timestamp": now(), "hc": hc, "hcp": hcp, "nodepools": pools,
                       "nodes": nodes, "clusterversion": cv, "operators": operators,
                       "components": components, "cluster_api": capi}
                with records.open("a") as stream:
                    stream.write(json.dumps(row) + "\n")
                flags = []
                for obj in [hc, hcp]:
                    cs = {c["type"]: c for c in obj.get("status", {}).get("conditions", [])}
                    a = cs.get("Available", {})
                    flags.append(a.get("status") == "True"
                                 and a.get("observedGeneration") == obj["metadata"]["generation"])
                hashes = {}
                for pool in pools:
                    cs = {c["type"]: c for c in pool.get("status", {}).get("conditions", [])}
                    for kind in ["Ready", "AllMachinesReady", "AllNodesHealthy"]:
                        condition = cs.get(kind, {})
                        flags.append(condition.get("status") == "True"
                                     and condition.get("observedGeneration") == pool["metadata"]["generation"])
                    flags += [cs.get("UpdatingConfig", {}).get("status") == "False",
                              cs.get("UpdatingVersion", {}).get("status") == "False",
                              pool.get("status", {}).get("version") == version,
                              pool.get("status", {}).get("replicas") == pool["spec"]["replicas"]]
                    hashes[pool["metadata"]["name"]] = pool["metadata"].get("annotations", {}).get(PREFIX + "nodePoolCurrentRolloutConfig")
                    if previous_hashes:
                        flags.append(bool(hashes[pool["metadata"]["name"]]) and
                                     hashes[pool["metadata"]["name"]] != previous_hashes.get(pool["metadata"]["name"]))
                flags.append(bool(pools))
                if expected_hashes is not None:
                    flags.append(hashes == expected_hashes)
                ready_nodes = [n for n in nodes["items"] if any(c["type"] == "Ready" and c["status"] == "True" for c in n["status"]["conditions"])]
                flags.append(len(ready_nodes) == sum(p["spec"]["replicas"] for p in pools))
                cvs = cv.get("status", {})
                cvc = {c["type"]: c["status"] for c in cvs.get("conditions", [])}
                flags += [cvs.get("observedGeneration") == cv["metadata"]["generation"],
                          cvc.get("Available") == "True", cvc.get("Progressing") == "False",
                          cvc.get("Failing") == "False", cvs.get("desired", {}).get("version") == version,
                          bool(cvs.get("history")) and cvs["history"][0].get("state") == "Completed"]
                flags.append(len(operators["items"]) >= 20)
                for operator in operators["items"]:
                    cs = {c["type"]: c["status"] for c in operator.get("status", {}).get("conditions", [])}
                    flags.append(cs.get("Available") == "True" and cs.get("Progressing") == "False" and cs.get("Degraded") == "False")
                for component in components["items"]:
                    cs = {c["type"]: c["status"] for c in component.get("status", {}).get("conditions", [])}
                    flags.append(cs.get("Available") == "True" and cs.get("RolloutComplete") == "True")
                cpv = hcp.get("status", {}).get("controlPlaneVersion", {})
                flags.append(cpv.get("observedGeneration") == hcp["metadata"]["generation"]
                             and cpv.get("desired", {}).get("version") == version
                             and bool(cpv.get("history")) and cpv["history"][0].get("state") == "Completed")
                hcv = hc.get("status", {}).get("version", {})
                flags.append(hcv.get("desired", {}).get("version") == version
                             and bool(hcv.get("history")) and hcv["history"][0].get("state") == "Completed")
                if all(flags):
                    self.save(phase, "readiness-complete", {"completed_at": now(), "version": version,
                              "ready_nodes": len(ready_nodes), "config_hashes": hashes, "all_gates_passed": True})
                    return hashes
                self.save(phase, "readiness-progress", {"observed_at": now(), "satisfied_gates": sum(flags),
                          "total_gates": len(flags), "ready_nodes": len(ready_nodes), "config_hashes": hashes})
            except (RuntimeError, subprocess.TimeoutExpired, FileNotFoundError) as error:
                self.save(phase, "readiness-query-error", {"timestamp": now(), "error": str(error)})
            time.sleep(20)
        raise TimeoutError("Full cluster readiness did not converge for " + phase)

    def connectivity(self, phase):
        ready = self.oc("guest", "get", "--raw=/readyz")
        assert ready.strip() == "ok", ready
        image = "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:6f38d442c105bbdfcf91cf6aa2a59db6a84ef1e4aab0e9033c0f273545db61a0b"
        release = json.loads((ROOT / "private/target-release.json").read_text())
        for tag in release["references"]["spec"]["tags"]:
            if tag["name"] == "cli":
                image = tag["from"]["name"]
                break
        pod_name = "verification-outbound-" + str(int(time.time()))
        pod = {"apiVersion": "v1", "kind": "Pod", "metadata": {"name": pod_name, "namespace": "default"},
               "spec": {"restartPolicy": "Never", "containers": [{"name": "curl", "image": image,
                   "command": ["/bin/bash", "-ec", "curl --fail --silent --show-error --max-time 30 --output /dev/null --write-out 'HTTPS %{http_code}\\n' https://quay.io/v2/"]}]}}
        # Quay /v2/ requires authentication. A public release API tests ordinary public TLS instead.
        pod["spec"]["containers"][0]["command"][-1] = "curl --fail --silent --show-error --max-time 30 --output /dev/null --write-out 'HTTPS %{http_code}\\n' https://mirror.openshift.com/pub/openshift-v4/clients/ocp/"
        try:
            self.oc("guest", "create", "-f", "-", body=pod)
            self.wait(phase + "-outbound", lambda: self.get("guest", "pod", pod_name, "default")["status"].get("phase") == "Succeeded", timeout=300)
            logs = self.oc("guest", "logs", pod_name, "-n", "default")
            self.save(phase, "connectivity", {"checked_at": now(), "api_readyz": ready, "outbound_https": logs})
        except Exception:
            self.save(phase, "connectivity-failure-pod", self.get("guest", "pod", pod_name, "default", optional=True))
            self.save(phase, "connectivity-failure-logs", self.oc("guest", "logs", pod_name, "-n", "default"))
            raise
        finally:
            self.oc("guest", "delete", "pod", pod_name, "-n", "default", "--ignore-not-found", "--wait=false")

    def provenance(self, phase, expected=None):
        deployments = self.get("management", "deployments", namespace=self.cpns)
        pods = self.get("management", "pods", namespace=self.cpns)
        self.save(phase, "deployments", deployments)
        self.save(phase, "running-pods", pods)
        self.save(phase, "hostedcluster", self.get("management", "hc", self.name, NS))
        self.save(phase, "hostedcontrolplane", self.get("management", "hcp", self.name, self.cpns))
        if expected:
            matching = []
            for name in ["control-plane-operator", "hosted-cluster-config-operator"]:
                deployment = next(d for d in deployments["items"] if d["metadata"]["name"] == name)
                requested = [c for c in deployment["spec"]["template"]["spec"]["containers"] if c["image"] == expected]
                assert requested, name + " does not request the source-pinned image"
                names = {c["name"] for c in requested}
                selector = deployment["spec"]["selector"]["matchLabels"]
                running = [p for p in pods["items"] if all(p["metadata"].get("labels", {}).get(k) == v for k, v in selector.items())]
                matches = [s for p in running for s in p.get("status", {}).get("containerStatuses", [])
                           if s["name"] in names and s.get("ready") and expected.split("@")[-1] in s.get("imageID", "")]
                assert matches, name + " has no Ready container with the expected running digest"
                matching.append({"deployment": name, "requested_image": expected, "running_containers": matches})
            self.save(phase, "provenance-assertions", {"passed": True, "collected_at": now(), "components": matching})

    def observed(self, phase):
        result = {"build": self.get("guest", "builds.config.openshift.io", "cluster"),
                  "project": self.get("guest", "projects.config.openshift.io", "cluster"),
                  "hcp": self.get("management", "hcp", self.name, self.cpns)}
        for kind in ["build", "project"]:
            name = "observed-config-" + kind
            result["observed-" + kind] = self.get("management", "cm", name, self.cpns)
            destinations = self.oc("guest", "get", "cm", "--all-namespaces", "--field-selector",
                                   "metadata.name=" + name, "-o", "json")
            result["guest-destinations-" + kind] = destinations
            assert destinations["items"] == []
            refs = result["observed-" + kind]["metadata"].get("ownerReferences", [])
            assert any(r["uid"] == result["hcp"]["metadata"]["uid"] and
                       r["name"] == self.name for r in refs)
        self.save(phase, "observed-config", result)
        return result

    def projection(self, configmap):
        payload = yaml.safe_load(configmap["data"]["config"])
        return {"apiVersion": payload.get("apiVersion"), "kind": payload.get("kind"),
                "name": payload.get("metadata", {}).get("name"), "spec": semantic_spec(payload.get("spec", {}))}

    def observed_matches(self, kind, source):
        cm = self.get("management", "cm", "observed-config-" + kind, self.cpns)
        payloads = []
        for value in cm.get("data", {}).values():
            try:
                payloads.append(yaml.safe_load(value))
            except (ValueError, yaml.YAMLError):
                pass
        return any(isinstance(v, dict) and semantic_spec(v.get("spec", {})) == semantic_spec(source.get("spec", {})) for v in payloads)

    def propagation(self):
        before = self.observed("TC-PROP-001/before")
        build_spec, project_spec = copy.deepcopy(before["build"].get("spec", {})), copy.deepcopy(before["project"].get("spec", {}))
        observers = []
        for kind in ["builds.config.openshift.io", "projects.config.openshift.io"]:
            path = self.directory / "TC-PROP-001" / (kind + "-watch.json")
            out = path.open("w")
            err = path.with_suffix(".stderr").open("w")
            process = subprocess.Popen(["oc", "--kubeconfig", str(self.guest), "get", kind, "cluster",
                                        "--watch", "--output-watch-events", "-o", "json"], stdout=out, stderr=err)
            observers.append((process, out, err))
        time.sleep(2)
        try:
            changed = copy.deepcopy(build_spec)
            changed.setdefault("buildDefaults", {}).setdefault("env", []).append({"name": "VERIFICATION_CNTRLPLANE_4338", "value": "build-only-" + str(int(time.time()))})
            new_build = self.patch("guest", "builds.config.openshift.io", "cluster", {"spec": changed})
            self.save("TC-PROP-001/build-change", "source-update", new_build)
            self.wait("build-projection", lambda: self.observed_matches("build", new_build))
            after_build = self.observed("TC-PROP-001/after-build")
            assert self.projection(after_build["observed-project"]) == self.projection(before["observed-project"])
            changed_project = dict(project_spec, projectRequestMessage="project-only-" + str(int(time.time())))
            new_project = self.patch("guest", "projects.config.openshift.io", "cluster", {"spec": changed_project})
            self.save("TC-PROP-001/project-change", "source-update", new_project)
            self.wait("project-projection", lambda: self.observed_matches("project", new_project))
            after_project = self.observed("TC-PROP-001/after-project")
            assert self.projection(after_project["observed-build"]) == self.projection(after_build["observed-build"])
        finally:
            self.oc("guest", "patch", "builds.config.openshift.io", "cluster", "--type=json", "-p",
                    json.dumps([{"op": "replace", "path": "/spec", "value": build_spec}]))
            restored_build = self.get("guest", "builds.config.openshift.io", "cluster")
            self.wait("build-restoration", lambda: self.observed_matches("build", restored_build))
            self.observed("TC-PROP-001/restored-build")
            self.oc("guest", "patch", "projects.config.openshift.io", "cluster", "--type=json", "-p",
                    json.dumps([{"op": "replace", "path": "/spec", "value": project_spec}]))
            restored_project = self.get("guest", "projects.config.openshift.io", "cluster")
            self.wait("project-restoration", lambda: self.observed_matches("project", restored_project))
            final = self.observed("TC-PROP-001/restored")
            assert self.projection(final["observed-build"]) == self.projection(before["observed-build"])
            assert self.projection(final["observed-project"]) == self.projection(before["observed-project"])
            time.sleep(30)
            stable = self.observed("TC-PROP-001/stability-30-seconds")
            assert self.projection(stable["observed-build"]) == self.projection(final["observed-build"])
            assert self.projection(stable["observed-project"]) == self.projection(final["observed-project"])
            for process, out, err in observers:
                process.terminate()
                process.wait(timeout=15)
                out.close()
                err.close()
        self.save("TC-PROP-001", "assertions", {"propagation_routing_ownership_and_restoration": "pass",
                  "watch_trigger_attribution": "blocked",
                  "reason": "The pinned HCCO eventHandler enqueues an empty request for every watched resource and exposes no per-source enqueue/reconcile trace. Independent client watch events cannot establish HCCO trigger causality."})

    def config_snapshot(self, phase):
        state = {"hc": self.get("management", "hc", self.name, NS),
                 "hcp": self.get("management", "hcp", self.name, self.cpns),
                 "guest_image": self.get("guest", "images.config.openshift.io", "cluster"),
                 "guest_proxy": self.get("guest", "proxies.config.openshift.io", "cluster"),
                 "guest_nodes": self.get("guest", "nodes"),
                 "cluster_api": self.get("management", "machinedeployments.cluster.x-k8s.io,machinesets.cluster.x-k8s.io,machines.cluster.x-k8s.io", namespace=self.cpns),
                 "nodepools": [p for p in self.get("management", "np", namespace=NS)["items"] if p["spec"]["clusterName"] == self.name]}
        self.save(phase, "configuration", state)
        return state

    def restore_configuration(self, original):
        if original is None:
            self.patch("management", "hc", self.name, {"spec": {"configuration": None}}, NS)
        else:
            self.oc("management", "patch", "hc", self.name, "-n", NS, "--type=json", "-p",
                    json.dumps([{"op": "add", "path": "/spec/configuration", "value": original}]))

    def restore_global_config(self, version, before, baseline_hashes):
        original = copy.deepcopy(before["hc"]["spec"].get("configuration"))
        original_guest = copy.deepcopy(before["guest_image"]["spec"])
        annotation = "verification.hypershift.openshift.io/cntrlplane-4338"
        # An absent optional Image input preserves the guest spec. Project the
        # saved baseline explicitly before releasing that optional ownership.
        desired = copy.deepcopy(original or {})
        desired["image"] = original_guest
        self.restore_configuration(desired)
        def baseline_projected():
            image = self.get("guest", "images.config.openshift.io", "cluster")
            hcp = self.get("management", "hcp", self.name, self.cpns)
            return (semantic_spec(image["spec"]) == semantic_spec(original_guest)
                    and semantic_spec((hcp["spec"].get("configuration") or {}).get("image")) == semantic_spec(original_guest))
        self.wait("global-config-explicit-baseline-projection", baseline_projected, timeout=600)
        self.config_snapshot("TC-REG-007A/explicit-baseline-projection")
        self.restore_configuration(original)
        self.wait("global-desired-configuration-restoration", lambda: semantic_spec(
            self.get("management", "hcp", self.name, self.cpns)["spec"].get("configuration")) == semantic_spec(
            before["hcp"]["spec"].get("configuration")), timeout=600)
        self.readiness("TC-REG-007A/restored", version, expected_hashes=baseline_hashes)
        self.connectivity("TC-REG-007A/restored")
        self.patch("guest", "images.config.openshift.io", "cluster", {"metadata": {"annotations": {annotation: None}}})
        final = self.config_snapshot("TC-REG-007A/final")
        assert annotation not in final["guest_image"]["metadata"].get("annotations", {})
        assert final["hc"]["spec"].get("configuration") == original
        assert semantic_spec(final["guest_image"]["spec"]) == semantic_spec(original_guest)
        self.save("TC-REG-007A", "restoration-policy", {"completed_at": now(),
                  "baseline_projected_explicitly_through_hc": True,
                  "original_optional_desired_configuration_restored": True,
                  "guest_owned_spec_semantically_equals_baseline": True,
                  "zero_value_serialization_normalized": True,
                  "guest_destination_spec_manually_patched": False})

    def global_config(self, version):
        before = self.config_snapshot("TC-REG-007A/before")
        original = copy.deepcopy(before["hc"]["spec"].get("configuration"))
        original_guest = copy.deepcopy(before["guest_image"]["spec"])
        annotation = "verification.hypershift.openshift.io/cntrlplane-4338"
        baseline_hashes = self.readiness("TC-REG-007A/baseline-ready", version)
        hashes = baseline_hashes
        self.connectivity("TC-REG-007A/before")
        try:
            for number, registry in enumerate(["unused-4338-a.invalid", "unused-4338-b.invalid"], 1):
                phase = "TC-REG-007A/update-" + str(number)
                if number == 2:
                    self.patch("guest", "images.config.openshift.io", "cluster", {"metadata": {"annotations": {annotation: "preserve-me"}}})
                changed = copy.deepcopy(original or {})
                changed.setdefault("image", {}).setdefault("registrySources", {})["blockedRegistries"] = [registry]
                self.patch("management", "hc", self.name, {"spec": {"configuration": changed}}, NS)
                def projected():
                    hcp = self.get("management", "hcp", self.name, self.cpns)
                    image = self.get("guest", "images.config.openshift.io", "cluster")
                    return (hcp["spec"].get("configuration", {}).get("image", {}).get("registrySources", {}).get("blockedRegistries") == [registry]
                            and image["spec"].get("registrySources", {}).get("blockedRegistries") == [registry])
                self.wait(phase.replace("/", "-") + "-projection", projected, timeout=600)
                hashes = self.readiness(phase, version, previous_hashes=hashes)
                after = self.config_snapshot(phase)
                if number == 2:
                    assert after["guest_image"]["metadata"].get("annotations", {}).get(annotation) == "preserve-me"
                self.connectivity(phase)
        except Exception:
            self.config_snapshot("TC-REG-007A/failure-before-restoration")
            raise
        finally:
            self.restore_global_config(version, before, baseline_hashes)
        self.save("TC-REG-007A", "assertions", {"result": "pass", "tested_at": now(), "registry_updates": 2,
                  "annotation_preserved": True, "restoration_verified": True,
                  "worker_rollouts_and_connectivity_verified_after_each_change": True})

    def ca_snapshot(self, phase, sources):
        state = self.config_snapshot(phase)
        state["sources"] = {}
        for name in sources:
            copies = {}
            for cluster, ns, key in [("management", NS, "hc_source"), ("management", self.cpns, "hcp_copy"),
                                     ("guest", "openshift-config", "guest_copy")]:
                copies[key] = self.get(cluster, "cm", name, ns, optional=True)
            state["sources"][name] = copies
        state["user_ca"] = self.get("guest", "cm", "openshift-user-ca", "openshift-controller-manager", optional=True)
        self.save(phase, "ca-projections", state)
        return state

    def ca(self, version, resume_selected_a=False):
        sources = ["verification-4338-ca-a", "verification-4338-ca-b"]
        before = (json.loads((self.directory / "TC-CA-001/before/configuration.json").read_text())
                  if resume_selected_a else self.config_snapshot("TC-CA-001/before"))
        original = copy.deepcopy(before["hc"]["spec"].get("configuration"))
        proxy = (original or {}).get("proxy", {})
        assert not proxy.get("trustedCA", {}).get("name"), "This direct-connectivity fixture must begin without a custom CA dependency"
        assert not proxy.get("httpProxy") and not proxy.get("httpsProxy"), "Unexpected proxy dependency"
        baseline_hashes = (json.loads((self.directory / "TC-CA-001/baseline-ready/readiness-complete.json").read_text())["config_hashes"]
                           if resume_selected_a else self.readiness("TC-CA-001/baseline-ready", version))
        hashes = baseline_hashes
        if not resume_selected_a:
            self.connectivity("TC-CA-001/before")
        data = {}
        for name in sources:
            certificate = (ROOT / "private" / (name + ".crt")).read_text()
            data[name] = {"ca-bundle.crt": certificate}
        if not resume_selected_a:
            self.save("TC-CA-001", "cleanup-plan", {"registered_at": now(), "original_configuration": original,
                  "restore_before_deleting_test_sources": True,
                  "connectivity_independence": "Baseline HC has no proxy or custom trustedCA reference. API kubeconfig uses its original CA; the outbound test uses public system trust independently of both additional test roots."})
        for name in sources:
            if resume_selected_a:
                assert self.get("management", "cm", name, NS)["data"] == data[name]
            else:
                self.oc("management", "create", "-f", "-", body={"apiVersion": "v1", "kind": "ConfigMap",
                        "metadata": {"name": name, "namespace": NS}, "data": data[name]})
        try:
            if not resume_selected_a:
                self.ca_snapshot("TC-CA-001/sources-created", sources)
            for index, name in enumerate(sources):
                phase = "TC-CA-001/selected-" + ("a" if index == 0 else "b")
                assert self.get("management", "cm", name, NS)["data"] == data[name]
                changed = copy.deepcopy(original or {})
                changed.setdefault("proxy", {})["trustedCA"] = {"name": name}
                if resume_selected_a and index == 0:
                    current = self.get("management", "hc", self.name, NS)
                    assert current["metadata"]["uid"] == before["hc"]["metadata"]["uid"]
                    assert current["spec"]["configuration"]["proxy"]["trustedCA"]["name"] == name
                else:
                    self.patch("management", "hc", self.name, {"spec": {"configuration": changed}}, NS)
                def projected():
                    cp = self.get("management", "cm", name, self.cpns, optional=True)
                    guest = self.get("guest", "cm", name, "openshift-config", optional=True)
                    user = self.get("guest", "cm", "openshift-user-ca", "openshift-controller-manager", optional=True)
                    hcp = self.get("management", "hcp", self.name, self.cpns)
                    proxy_obj = self.get("guest", "proxies.config.openshift.io", "cluster")
                    return (all(c and c.get("data") == data[name] for c in [cp, guest, user])
                            and hcp["spec"].get("configuration", {}).get("proxy", {}).get("trustedCA", {}).get("name") == name
                            and proxy_obj["spec"].get("trustedCA", {}).get("name") == name)
                self.wait(phase.replace("/", "-") + "-projection", projected, timeout=600)
                if index:
                    self.wait("stale-ca-a-removal", lambda: self.get("management", "cm", sources[0], self.cpns, optional=True) is None
                              and self.get("guest", "cm", sources[0], "openshift-config", optional=True) is None)
                hashes = self.readiness(phase, version, previous_hashes=hashes)
                state = self.ca_snapshot(phase, sources)
                for source in sources:
                    assert state["sources"][source]["hc_source"]["data"] == data[source]
                self.connectivity(phase)
            self.restore_configuration(original)
            self.wait("ca-removal", lambda: self.get("guest", "cm", "openshift-user-ca", "openshift-controller-manager", optional=True) is None
                      and self.get("guest", "cm", sources[1], "openshift-config", optional=True) is None
                      and self.get("management", "cm", sources[1], self.cpns, optional=True) is None, timeout=600)
            hashes = self.readiness("TC-CA-001/reference-removed", version, previous_hashes=hashes)
            removed = self.ca_snapshot("TC-CA-001/reference-removed", sources)
            for name in sources:
                assert removed["sources"][name]["hc_source"]["data"] == data[name]
            self.connectivity("TC-CA-001/reference-removed")
        except Exception:
            self.ca_snapshot("TC-CA-001/failure-before-restoration", sources)
            raise
        finally:
            self.restore_configuration(original)
            self.readiness("TC-CA-001/restored", version, expected_hashes=baseline_hashes)
            self.connectivity("TC-CA-001/restored")
            self.ca_snapshot("TC-CA-001/restored-before-source-cleanup", sources)
            for name in sources:
                self.oc("management", "delete", "cm", name, "-n", NS, "--ignore-not-found", "--wait=false")
            self.ca_snapshot("TC-CA-001/final", sources)
        self.save("TC-CA-001", "assertions", {"result": "pass", "tested_at": now(),
                  "selection_rotation_removal_restoration": True,
                  "operator_created_hcp_copies_only": True, "hc_sources_preserved_until_cleanup": True,
                  "worker_rollouts_and_connectivity_verified_after_each_change": True})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["ready", "provenance", "propagation", "connectivity", "global-config", "ca"])
    parser.add_argument("--name", required=True)
    parser.add_argument("--lifecycle", required=True)
    parser.add_argument("--version", default="4.21.0")
    parser.add_argument("--phase", default="baseline")
    parser.add_argument("--expected-image")
    args = parser.parse_args()
    os.umask(0o077)
    run = Run(args.name, args.lifecycle)
    if args.mode in ["propagation", "global-config", "ca"]:
        from validate_release_pair import validate
        validate(json.loads((ROOT / "private/previous-release.json").read_text()),
                 json.loads((ROOT / "private/target-release.json").read_text()))
    if args.mode == "ready":
        run.readiness(args.phase, args.version)
    elif args.mode == "provenance":
        run.provenance(args.phase, args.expected_image)
    elif args.mode == "connectivity":
        run.connectivity(args.phase)
    elif args.mode == "propagation":
        run.propagation()
    elif args.mode == "global-config":
        run.global_config(args.version)
    else:
        run.ca(args.version)


if __name__ == "__main__":
    main()
