#!/usr/bin/env python3
"""Run the three main-fixture procedures serially after full readiness and provenance."""
import json
import os

from live_tests import ROOT, Run, now
from validate_release_pair import validate


def main():
    os.umask(0o077)
    previous = json.loads((ROOT / "private/previous-release.json").read_text())
    target = json.loads((ROOT / "private/target-release.json").read_text())
    validate(previous, target)
    images = {i["flavor"]: i for i in json.loads((ROOT / "private/built-images.json").read_text())}
    run = Run("hc-4338-main", "main-lifecycle")
    version = target["metadata"]["version"]
    run.readiness("main-tests/full-readiness-before-mutations", version)
    run.provenance("main-tests/runtime-provenance-before-mutations", images["pr"]["image"])
    print("Full 5.1 readiness and CPO/HCCO runtime provenance passed.", flush=True)
    run.propagation()
    print("TC-PROP-001 propagation and restoration passed. Exact watch-trigger attribution remains blocked by missing source tracing.", flush=True)
    run.ca(version)
    print("TC-CA-001 selection, rotation, removal, and restoration passed.", flush=True)
    run.global_config(version)
    print("TC-REG-007A mutable image configuration and restoration passed.", flush=True)
    run.readiness("main-tests/final-restored-readiness", version)
    run.provenance("main-tests/final-runtime-provenance", images["pr"]["image"])
    run.save("main-tests", "completed", {"completed_at": now(), "fixture_retained": True,
             "all_mutated_configuration_restored": True})


if __name__ == "__main__":
    main()
