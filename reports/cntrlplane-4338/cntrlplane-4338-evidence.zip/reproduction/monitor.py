#!/usr/bin/env python3
"""Capture scoped lifecycle observations under the PR 10151 skill."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import stat
import time


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def query(kubeconfig, *args):
    command = ["oc", "--kubeconfig", str(kubeconfig), "--request-timeout=15s", *args]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=25)
    except subprocess.TimeoutExpired:
        return {"query_error": "Command timed out after 25 seconds", "exit_code": None}
    if result.returncode:
        return {"query_error": result.stderr, "exit_code": result.returncode}
    return json.loads(result.stdout) if result.stdout.strip() else None


def conditions(obj):
    if not obj or "query_error" in obj:
        return None
    generation = obj["metadata"].get("generation")
    return [{k: c.get(k) for k in ["type", "status", "observedGeneration", "lastTransitionTime"]}
            | {"fresh": c.get("observedGeneration") == generation}
            for c in obj.get("status", {}).get("conditions", [])]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--namespace", default="clusters")
    parser.add_argument("--kubeconfig", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--timeout", type=int, default=5400)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    os.umask(0o077)
    root = Path(args.output)
    if args.resume:
        info = root.stat()
        if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
            raise SystemExit("Resume requires an owned directory with mode 0700")
    else:
        root.mkdir(mode=0o700)
    guest = root / "guest.kubeconfig"
    deadline = time.monotonic() + args.timeout
    with (root / "observations.jsonl").open("a", buffering=1) as stream:
        while time.monotonic() < deadline:
            started = now()
            hc = query(args.kubeconfig, "get", "hc", args.name, "-n", args.namespace,
                       "--ignore-not-found", "-o", "json")
            hcpns = args.namespace + "-" + args.name.replace(".", "-")
            hcp = query(args.kubeconfig, "get", "hcp", args.name, "-n", hcpns,
                        "--ignore-not-found", "-o", "json")
            pools = query(args.kubeconfig, "get", "np", "-n", args.namespace, "-o", "json")
            pools = ([p for p in pools.get("items", []) if p["spec"]["clusterName"] == args.name]
                     if isinstance(pools, dict) and "query_error" not in pools else pools)
            row = {"started_at": started, "hc": hc, "hcp": hcp, "nodepools": pools}
            if hc and "query_error" not in hc and not guest.exists():
                secret_name = hc.get("status", {}).get("kubeconfig", {}).get("name")
                if secret_name:
                    secret = query(args.kubeconfig, "get", "secret", secret_name,
                                   "-n", args.namespace, "-o", "json")
                    if secret and "query_error" not in secret:
                        owners = secret["metadata"].get("ownerReferences", [])
                        if any(o.get("uid") == hc["metadata"]["uid"] for o in owners):
                            import base64
                            guest.write_bytes(base64.b64decode(secret["data"]["kubeconfig"]))
                            guest.chmod(0o600)
            if guest.exists():
                row["guest_version"] = query(guest, "get", "clusterversion", "version", "-o", "json")
                if row["guest_version"] and "query_error" not in row["guest_version"]:
                    row["guest_operators"] = query(guest, "get", "clusteroperators", "-o", "json")
                    row["guest_nodes"] = query(guest, "get", "nodes", "-o", "json")
            row["finished_at"] = now()
            stream.write(json.dumps(row) + "\n")
            summary = {"collected_at": row["finished_at"], "hc_present": bool(hc),
                       "hc_conditions": conditions(hc), "hcp_conditions": conditions(hcp),
                       "guest_observation_available": "guest_version" in row}
            (root / "latest-summary.json").write_text(json.dumps(summary, indent=2))
            if (root / "stop").exists():
                break
            time.sleep(20)


if __name__ == "__main__":
    main()
