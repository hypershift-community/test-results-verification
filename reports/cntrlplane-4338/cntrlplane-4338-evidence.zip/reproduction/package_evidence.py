#!/usr/bin/env python3
"""Stage explicitly selected evidence, sanitize it, scan uncompressed, then ZIP."""
import argparse
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import urlsplit, urlunsplit
import zipfile

ROOT = Path(__file__).resolve().parent
STAGE = ROOT / "sanitized-evidence"
DEST = ROOT / "delivery/reports/cntrlplane-4338"
CHUNKS = []


def pseudonym(value):
    return hashlib.sha256(value.encode()).hexdigest()[:12]


def sanitize_text(text):
    public_citations = {}
    def preserve_ci_reference(match):
        token = "PUBLIC_CI_REFERENCE_" + str(len(public_citations))
        public_citations[token] = match[0]
        return token
    text = re.sub(r"https://endpoint-c0b0109d9439.example.com\.com/openshift/hypershift/actions/runs/[0-9]+/job/[0-9]+", preserve_ci_reference, text)
    inventory = ROOT / "private/upgrade-cleanup/aws-before.json"
    if inventory.exists():
        captured = json.loads(inventory.read_text())
        buckets = captured.get("RegistryBuckets", []) + [captured.get("OIDCStorage", {}).get("bucket")]
        for bucket in buckets:
            if bucket:
                text = text.replace(bucket, "bucket-" + pseudonym(bucket))
    for source, replacement in [
        ("hc-4338-upgrade", "hc-4338-upgrade"), ("hc-4338-main", "hc-4338-main"),
        ("/work/operator", "/work/operator"), ("test.example.com", "test.example.com"),
        ("test-operator", "test-operator"), ("test-operator", "test-operator"), ("test-operator", "test-operator"),
    ]:
        text = text.replace(source, replacement)
    text = re.sub(r"(?<![\w])\d{12}(?![\w])", "123456789012", text)
    text = re.sub(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
                  lambda m: "uid-" + pseudonym(m[0]), text, flags=re.I)
    text = re.sub(r"\b(?:vpc|subnet|sg|eni|nat|igw|rtb|eipalloc|eipassoc|vpce|vol|snap|ami|i|r)-[0-9a-f]{8,17}\b",
                  lambda m: m[0].split("-")[0] + "-redacted-" + pseudonym(m[0]), text)
    text = re.sub(r"\b(?:AIDA|AROA|AIPA|AGPA|ANPA|ANVA|AOPA|AUPA)[A-Z0-9]{17}\b",
                  lambda m: "iam-redacted-" + pseudonym(m[0]), text)
    text = re.sub(r"\bec2-(?:[0-9]{1,3}-){3}[0-9]{1,3}\.(?:[a-z0-9-]+\.)?compute(?:-1)?\.amazonaws\.com\b",
                  lambda m: "endpoint-" + pseudonym(m[0]) + ".example.com", text)
    text = re.sub(r"[A-Za-z0-9_.-]+\.(?:internal|local|svc|corp)(?=[\s\"':/,)}\]\\]|$)",
                  lambda m: "host-" + pseudonym(m[0]) + ".example.com", text)
    text = re.sub(r"[A-Za-z0-9_.-]+\.(?:elb\.(?:[A-Za-z0-9-]+\.)?amazonaws\.com|s3(?:[.-][A-Za-z0-9-]+)?\.amazonaws\.com|hypershift\.devcluster\.openshift\.com)",
                  lambda m: "endpoint-" + pseudonym(m[0]) + ".example.com", text)
    public_hosts = {"github.com", "api.github.com", "raw.githubusercontent.com", "quay.io", "registry.redhat.io",
                    "registry.access.redhat.com", "mirror.openshift.com", "multi.ocp.releases.ci.openshift.org",
                    "redhat.atlassian.net", "issues.redhat.com", "access.redhat.com", "docs.openshift.com",
                    "docs.aws.amazon.com", "prow.ci.openshift.org", "sts.amazonaws.com", "s3.amazonaws.com", "localhost", "127.0.0.1", "::1",
                    "example.com", "example.org", "example.net"}
    def endpoint(match):
        raw = match[0]
        try:
            parsed = urlsplit(raw)
            host = parsed.hostname
            if parsed.username is not None or parsed.password is not None:
                return "https://redacted.example.com/credential-url-omitted"
            if not host or host in public_hosts or host.endswith((".example.com", ".example.org", ".example.net", ".test", ".invalid")):
                return raw
            netloc = "endpoint-" + pseudonym(host) + ".example.com"
            try:
                port = parsed.port
            except ValueError:
                port = None
            if port:
                netloc += ":" + str(port)
            return urlunsplit((parsed.scheme, netloc, parsed.path, parsed.query, parsed.fragment))
        except ValueError:
            return raw
    text = re.sub(r"https?://[^\s<>\"'`\\]+", endpoint, text)
    def address(match):
        try:
            ip = ipaddress.ip_address(match[0])
        except ValueError:
            return match[0]
        if ip.is_loopback or str(ip).startswith(("192.0.2.", "198.51.100.", "203.0.113.")):
            return match[0]
        return "192.0.2." + str(1 + int(pseudonym(match[0]), 16) % 253)
    text = re.sub(r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])", address, text)
    for token, citation in public_citations.items():
        text = text.replace(token, citation)
    return text


def trim_metadata(value):
    if isinstance(value, list):
        return [trim_metadata(v) for v in value]
    if isinstance(value, dict):
        if value.get("kind") == "Secret":
            assert not any(k in value for k in ["metadata", "data", "stringData"]), "Secret resources must never enter ordinary evidence"
            return {"kind": "Secret", "name": "REDACTED_SECRET_REFERENCE"}
        result = {}
        for k, v in value.items():
            if k in {"managedFields", "kubectl.kubernetes.io/last-applied-configuration"}:
                continue
            if k in {"httpSecret", "clientSecret", "accessKeyID", "secretAccessKey", "sessionToken", "privateKey"}:
                result[k] = "REDACTED"
            elif k in {"secretName", "pullSecret", "sshKey", "kubeconfig", "adminKubeconfig", "kubeadminPassword",
                     "serviceAccountSigningKey", "imagePullSecrets", "secretKeyRef", "secretRef"}:
                result[k] = "REDACTED_SECRET_REFERENCE"
            else:
                result[k] = trim_metadata(v)
        return result
    return value


def copy(source, relative):
    os.umask(0o077)
    assert source.is_file(), source
    raw = source.read_bytes()
    assert b"\x00" not in raw, "Corrupt text is excluded: " + str(source)
    text = raw.decode("utf-8")
    assert not re.search(r"-----BEGIN (?:[A-Z ]*PRIVATE KEY|OPENSSH PRIVATE KEY)-----", text)
    if source.suffix == ".json":
        try:
            value = json.loads(text)
        except json.JSONDecodeError:
            assert source.name.endswith("-watch.json")
            value = []
            decoder = json.JSONDecoder()
            while text.strip():
                event, end = decoder.raw_decode(text.lstrip())
                value.append(event)
                text = text.lstrip()[end:]
        text = json.dumps(trim_metadata(value), indent=2)
    elif source.suffix == ".jsonl":
        text = "\n".join(json.dumps(trim_metadata(json.loads(line))) for line in text.splitlines() if line.strip()) + "\n"
    output = STAGE / relative
    output.parent.mkdir(parents=True, exist_ok=True)
    encoded = sanitize_text(text).encode("utf-8")
    if source.suffix == ".jsonl" and len(encoded) > 4 * 1024 * 1024:
        parts, pending, size = [], [], 0
        for line in encoded.splitlines(keepends=True):
            assert len(line) <= 4 * 1024 * 1024, "An individual evidence record needs a smaller projection"
            if pending and size + len(line) > 4 * 1024 * 1024:
                part = output.with_name(output.stem + f".part-{len(parts)+1:03d}.jsonl")
                part.write_bytes(b"".join(pending));parts.append(str(part.relative_to(STAGE)))
                pending, size = [], 0
            pending.append(line);size += len(line)
        if pending:
            part = output.with_name(output.stem + f".part-{len(parts)+1:03d}.jsonl")
            part.write_bytes(b"".join(pending));parts.append(str(part.relative_to(STAGE)))
        CHUNKS.append({"original_stream_path": str(relative), "parts_in_order": parts,
                       "sanitized_stream_sha256": hashlib.sha256(encoded).hexdigest(),
                       "record_count": len(encoded.splitlines())})
    else:
        output.write_bytes(encoded)


def stage():
    os.umask(0o077)
    CHUNKS.clear()
    if STAGE.exists():
        shutil.rmtree(STAGE)
    STAGE.mkdir()
    for p in sorted((ROOT / "evidence").rglob("*")):
        if p.is_file():
            copy(p, Path("evidence") / p.relative_to(ROOT / "evidence"))
    for name in ["pr-unit-verbose.log", "baseline-unit-retry.log", "baseline-inputs-focused.log",
                 "copied-create-script-run.log", "built-images.json", "baseline-machine-approver-compatibility.json",
                 "native-image-build-retry.log", "main-create.log", "upgrade-create-attempt2.log",
                 "main-create-metadata.json", "main-create-result.json", "upgrade-create-metadata.json", "upgrade-create-result.json",
                 "main-cases-retry.log", "main-cases-continued.log", "main-restoration-continued.log", "upgrade-case.log", "clean-propagation-final.log"]:
        copy(ROOT / "private" / name, Path("execution") / name)
    for cluster in ["hc-4338-main", "hc-4338-upgrade"]:
        directory = ROOT / "private/live" / cluster
        for p in sorted(directory.rglob("*")):
            rel = p.relative_to(directory)
            if p.is_file() and (rel.parts[0].startswith("TC-") or rel.parts[0] == "main-tests" or str(rel) == "operations.jsonl"):
                copy(p, Path("live") / sanitize_text(cluster) / rel)
    for lifecycle in ["main-lifecycle", "upgrade-lifecycle"]:
        copy(ROOT / "private" / lifecycle / "observations.jsonl", Path("lifecycle") / lifecycle / "observations.jsonl")
    for p in sorted((ROOT / "private/upgrade-cleanup").rglob("*")):
        if p.is_file():
            copy(p, Path("cleanup") / p.relative_to(ROOT / "private/upgrade-cleanup"))
    for name in ["test-plan.md", "plan-provenance.json"]:
        copy(ROOT / "source" / name, Path("source") / name.replace(".md", ".txt"))
    for name in ["live_tests.py", "main_tests.py", "upgrade_test.py", "monitor.py", "teardown_upgrade.py",
                 "prepare_retrospective.py", "summarize_units.py", "validate_release_pair.py", "build_images.py",
                 "audit_results.py", "report_results.py", "render_report.py", "package_evidence.py", "verify_image_policy_stability.py",
                 "restore_unit_sources.py", "test_review_fixes.py"]:
        copy(ROOT / name, Path("reproduction") / name)
    copy(ROOT / "scripts/create_hosted_cluster_on_aws.sh", Path("reproduction/create_hosted_cluster_on_aws.sh"))
    prefix = Path("control-plane-operator/hostedclusterconfigoperator/controllers/resources")
    fixtures = []
    for flavor in ["hypershift-pr", "hypershift-baseline"]:
        directory = ROOT / "source" / flavor / prefix
        for p in sorted(directory.glob("retrospective*")) + sorted(directory.glob("foundation_order_test.go")) + sorted((directory / "configuration").glob("*_test.go")):
            relative = Path("source") / flavor / p.relative_to(directory)
            copy(p, relative)
            fixtures.append({"archive_path": str(relative), "flavor": flavor,
                             "relative_path": str(p.relative_to(directory)),
                             "original_sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                             "transformed_sha256": hashlib.sha256((STAGE / relative).read_bytes()).hexdigest()})
    replay = {"head_revision": "d037aa90aa5b889c69464004df2e74f4c4c5b287",
              "baseline_revision": "b0edc822e1ffb9f0527091a764d940b81b2c34a8",
              "stored_source_scope": "Transformed evidence copies, not executable overlays. Generic hostname, address and operator-name substitutions can alter upstream test literals.",
              "reconstruction": "Use reproduction/restore_unit_sources.py with a checkout containing the pinned public head. It reads exact upstream files with git show, derives baseline replay tests with prepare_retrospective.py, and verifies every original SHA-256 before returning the files.",
              "fixtures": fixtures}
    (STAGE / "source/replay-manifest.json").write_text(json.dumps(replay, indent=2))
    (STAGE / "README.txt").write_text("Sanitized evidence for CNTRLPLANE-4338. This is execution evidence, not a portable provisioning kit.\n"
        "Before/after source revisions, versions, image digests, timestamps, values, conditions and test outcomes are retained.\n"
        "Operator names, local paths, live identifiers, IP addresses and cluster endpoints are replaced consistently.\n"
        "Kubernetes managedFields and last-applied annotations are omitted. Private originals remain outside this archive.\n"
        "No Secrets, kubeconfigs, private keys, AWS session files or CSRs are selected. Discarded/corrupt watch attempts are excluded.\n"
        "Reproduction scripts require authorized credentials and local paths to be configured; do not run them as report readers.\n"
        "Go sources under source/hypershift-pr and source/hypershift-baseline are transformed evidence copies, not executable overlays. Their upstream hostname literals may have changed. source/replay-manifest.json records both original and transformed hashes. Use reproduction/restore_unit_sources.py --head-checkout /path/to/pinned-head --output /path/to/new-output to reconstruct and verify exact original head and retrospective baseline tests from public upstream source.\n"
        "Large JSONL streams are split at record boundaries into ordered parts under 4 MiB. chunk-index.json records reassembly order and complete sanitized stream hashes; every observation in each retained stream is preserved. Discarded/corrupt watch attempts remain excluded as disclosed above.\n"
        "A sanitized copy of the supplied plan is retained as source/test-plan.txt. Public CI citations are preserved; source/plan-provenance.json identifies the pinned original. Upstream plan-v4 validator incompatibilities are reported separately.\n"
        "All previously published artifact paths remain in this ZIP. Original creation metadata is unchanged; evidence/provenance/creation-metadata-clarification.json identifies stale descriptive release labels and the authoritative release captures.\n")
    (STAGE / "chunk-index.json").write_text(json.dumps(CHUNKS, indent=2))
    print("Staged", rebuild_manifest(), "sanitized evidence files.")


def rebuild_manifest():
    manifest = [{"path": str(p.relative_to(STAGE)), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                 "bytes": p.stat().st_size} for p in sorted(STAGE.rglob("*")) if p.is_file() and p != STAGE / "manifest.json"]
    (STAGE / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return len(manifest)


def scan_and_zip():
    rebuild_manifest()
    env = dict(os.environ, PATH=str(ROOT / "verification-repo/bin") + os.pathsep + os.environ["PATH"])
    command = [str(ROOT / "verification-repo/bin/verify-artifacts"), "--root", str(STAGE), "--secrets", "--format", "json"]
    result = subprocess.run(command, capture_output=True, text=True, env=env, timeout=180)
    (ROOT / "private/evidence-lint.json").write_text(result.stdout)
    (ROOT / "private/evidence-lint.stderr").write_text(result.stderr)
    if result.returncode:
        raise SystemExit("Uncompressed evidence scan failed; see restricted diagnostics")
    DEST.mkdir(parents=True, exist_ok=True)
    archive = DEST / "cntrlplane-4338-evidence.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(STAGE.rglob("*")):
            if p.is_file():
                z.write(p, str(p.relative_to(STAGE)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    print("Scanned uncompressed evidence and verified ZIP integrity:", archive.stat().st_size, "bytes")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--scan-and-zip", action="store_true")
    args = parser.parse_args()
    if args.scan_and_zip:
        scan_and_zip()
    else:
        stage()
