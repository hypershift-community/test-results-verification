#!/usr/bin/env python3
"""Replay pinned characterization fixtures against the pre-extraction root API."""
import argparse
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
root = parser.parse_args().root
prefix = Path("control-plane-operator/hostedclusterconfigoperator/controllers/resources")
head = root / "source/hypershift-pr" / prefix
base = root / "source/hypershift-baseline" / prefix

for name in ["global_test.go", "image_policy_test.go", "observed_test.go",
             "proxy_test.go", "inputs_test.go", "install_test.go", "test_helpers_test.go"]:
    source = (head / "configuration" / name).read_text()
    source = source.replace("package configuration\n", "package resources\n", 1)
    source = source.replace("func Test", "func TestRetrospective")
    source = source.replace("compareICSAndIDMS", "retrospectiveCompareICSAndIDMS")
    source = source.replace("withICS", "retrospectiveWithICS")
    if name == "install_test.go":
        source = source.replace("release.ComponentVersions", "release")
    if name == "test_helpers_test.go":
        source = source[:source.index("type simpleCreateOrUpdater struct{}")]
    (base / ("retrospective_" + name)).write_text(source)

for name in ["adapters.go", "inputs.go"]:
    source = (head / "configuration" / name).read_text()
    (base / ("retrospective_" + name.replace(".go", "_shim_test.go"))).write_text(
        source.replace("package configuration\n", "package resources\n", 1))
old_adapters = base / "retrospective_adapters_test.go"
if old_adapters.exists():
    old_adapters.unlink()

(base / "foundation_order_test.go").write_text((head / "foundation_order_test.go").read_text())
(base / "retrospective_entrypoints_test.go").write_text('''package resources

import (
    "context"
    hyperv1 "github.com/openshift/hypershift/api/hypershift/v1beta1"
    "github.com/openshift/hypershift/support/releaseinfo"
    configv1 "github.com/openshift/api/config/v1"
    metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
    utilerrors "k8s.io/apimachinery/pkg/util/errors"
)

func legacyRoot(hosted HostedCluster, controlPlane ControlPlane) *reconciler {
    return &reconciler{client: hosted.client, cpClient: controlPlane.client,
        CreateOrUpdateProvider: configurationUpserter{hosted.createOrUpdate}}
}

func ReconcileGlobal(ctx context.Context, hosted HostedCluster, cp ControlPlane, hcp *hyperv1.HostedControlPlane) error {
    return legacyRoot(hosted, cp).reconcileConfig(ctx, hcp)
}

func ReconcileImagePolicy(ctx context.Context, hosted HostedCluster, sources []hyperv1.ImageContentSource) error {
    return legacyRoot(hosted, ControlPlane{}).reconcileImageContentPolicyType(ctx,
        &hyperv1.HostedControlPlane{Spec: hyperv1.HostedControlPlaneSpec{ImageContentSources: sources}})
}

func ReconcileInstallMetadata(ctx context.Context, hosted HostedCluster, release *releaseinfo.ReleaseImage) error {
    return legacyRoot(hosted, ControlPlane{}).reconcileInstallConfigMap(ctx, release)
}

func ReconcileObserved(ctx context.Context, hosted HostedCluster, cp ControlPlane, params ObservedConfigParams) error {
    hcp := &hyperv1.HostedControlPlane{ObjectMeta: metav1.ObjectMeta{
        Namespace: params.Namespace, Name: params.OwnerRef.Reference.Name, UID: params.OwnerRef.Reference.UID}}
    return utilerrors.NewAggregate(legacyRoot(hosted, cp).reconcileObservedConfiguration(ctx, hcp))
}

func proxyFixture(params ProxyParams) *hyperv1.HostedControlPlane {
    return &hyperv1.HostedControlPlane{ObjectMeta: metav1.ObjectMeta{Namespace: params.Namespace},
        Spec: hyperv1.HostedControlPlaneSpec{Configuration: &hyperv1.ClusterConfiguration{
            Proxy: &configv1.ProxySpec{TrustedCA: configv1.ConfigMapNameReference{Name: params.TrustedCA}}}}}
}

func ReconcileProxyTrustedCA(ctx context.Context, hosted HostedCluster, cp ControlPlane, params ProxyParams) error {
    return legacyRoot(hosted, cp).reconcileProxyTrustedCAConfigMap(ctx, proxyFixture(params))
}

func ReconcileProxyCABundle(ctx context.Context, hosted HostedCluster, cp ControlPlane, params ProxyParams) error {
    return legacyRoot(hosted, cp).reconcileProxyCABundle(ctx, proxyFixture(params))
}
''')
files = [str(p) for p in base.glob("retrospective_*_test.go")]
subprocess.run(["gofmt", "-w", *files, str(base / "foundation_order_test.go")], check=True)
print("Prepared test-only adapters; baseline product implementation is unchanged.")
