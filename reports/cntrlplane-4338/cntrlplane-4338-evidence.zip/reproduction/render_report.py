#!/usr/bin/env python3
"""Render a self-contained IEEE-style HTML bundle from verified result records."""
from collections import Counter
import hashlib
from html import escape
import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent
DEST = ROOT / "delivery/reports/cntrlplane-4338"
CSS = """
:root{--foreground:#17212d;--muted-foreground:#526173;--border:#d6dde5;--card:#f4f6f8;--success:#087748;--warning:#986300;--destructive:#a32a35;--primary:#175a99;--font-sans:system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;--font-mono:ui-monospace,SFMono-Regular,Consolas,monospace}
*{box-sizing:border-box}html,body{margin:0;background:none;color:var(--foreground);font-family:var(--font-sans);line-height:1.55}body{margin:0 5%}main{max-width:1080px;margin:0 auto;padding:0}h1{font-size:25px;line-height:1.25;margin:24px 0 10px}h2{font-size:20px;margin:30px 0 10px}h3{font-size:16px;margin:20px 0 8px}p{max-width:90ch}a{color:var(--primary)}nav{display:flex;gap:14px;flex-wrap:wrap;padding:12px 0;border-bottom:1px solid var(--border);font-size:13px}.muted,small{color:var(--muted-foreground)}.lead{font-size:17px}.status{font-size:12px;font-weight:650;text-transform:uppercase;letter-spacing:.04em}.pass{color:var(--success)}.blocked,.conditional{color:var(--warning)}.fail{color:var(--destructive)}table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:13px;margin:12px 0 22px}th,td{overflow-wrap:anywhere;text-align:left;vertical-align:top;padding:10px 8px;border-bottom:1px solid var(--border)}th{font-weight:650}.comparison{display:grid;grid-template-columns:1fr 1fr;gap:20px}.comparison section{min-width:0;padding:16px;background:var(--card);border-radius:6px}pre,code{font-family:var(--font-mono);font-size:12px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:var(--card);padding:12px;border-radius:5px}code{overflow-wrap:anywhere}.comparison pre{padding:0}.summary{display:flex;gap:30px;flex-wrap:wrap;margin:20px 0}.summary strong{display:block;font-size:25px}.evidence{font-size:13px}svg{max-width:100%;height:auto}footer{margin:30px 0 18px;padding-top:12px;border-top:1px solid var(--border);font-size:12px;color:var(--muted-foreground)}@media(max-width:680px){.comparison{grid-template-columns:1fr}table{font-size:12px}th,td{padding:8px 4px}h1{font-size:22px}}@media(prefers-color-scheme:dark){:root{--foreground:#e2e7ed;--muted-foreground:#a1adba;--border:#354253;--card:#202b37;--success:#63c69a;--warning:#e3ba6b;--destructive:#f28c97;--primary:#87bdf1}}@media print{nav{display:none}a{color:inherit}main{max-width:none}h2,h3{break-after:avoid}section,table{break-inside:avoid}:root{--foreground:#111;--muted-foreground:#444;--border:#bbb;--card:#f5f5f5}body{font-size:10pt}}
"""


def e(value):
    return escape(str(value), quote=True)


def paragraphs(values):
    return "".join("<p>" + e(v) + "</p>" for v in values)


def listing(values):
    return "<ul>" + "".join("<li>" + e(v) + "</li>" for v in values) + "</ul>"


def state(value):
    return "<pre>" + e(json.dumps(value, indent=2, ensure_ascii=False)) + "</pre>"


def badge(value, label=None):
    return '<span class="status ' + e(value) + '">' + e(label or value) + "</span>"


def page(title, body, data):
    return ("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>" + e(title) + "</title><style>" + CSS + "</style></head><body><main>"
            "<nav aria-label=\"Report navigation\"><a href=\"index.html\">Summary</a>"
            "<a href=\"automated-tests.html\">Automated tests</a><a href=\"appendices.html\">Environment and provenance</a>"
            "<a href=\"cntrlplane-4338-evidence.zip\" download>Evidence ZIP</a></nav>" + body
            + "<footer>CNTRLPLANE-4338 | PR #9920 | Generated " + e(data["generated_at"])
            + " | HTML is authoritative. Supporting logs and JSON are in the evidence ZIP.</footer></main></body></html>")


def chart(counts):
    rows = [(key, counts[key]) for key in ["pass", "blocked", "fail", "conditional"] if counts[key]]
    height = 55 + len(rows) * 34
    parts = [f'<svg viewBox="0 0 640 {height}" role="img" aria-label="Scenario verdict counts">']
    for index, (key, count) in enumerate(rows):
        y = 15 + index * 34
        color = {"pass": "--success", "blocked": "--warning", "conditional": "--warning", "fail": "--destructive"}[key]
        label = "LIMITATION" if key == "blocked" else key.upper()
        parts += [f'<text x="0" y="{y+16}" fill="var(--foreground)" font-size="12">{label}</text>',
                  f'<rect x="100" y="{y}" width="{count*50}" height="23" fill="var({color})" rx="2"/>',
                  f'<text x="{110+count*50}" y="{y+16}" fill="var(--foreground)" font-size="12">{count}</text>']
    axis = 25 + len(rows) * 34
    parts.append(f'<text x="100" y="{axis}" fill="var(--muted-foreground)" font-size="11">Scenario count, out of 9</text></svg>')
    return "".join(parts)


def main():
    data = json.loads((ROOT / "evidence/report-results.json").read_text())
    cases = data["scenarios"]
    assert len(cases) == 9
    assert all(c["status"] in {"pass", "fail", "blocked", "conditional"} for c in cases)
    archive = DEST / "cntrlplane-4338-evidence.zip"
    assert archive.is_file(), "Package and scan the evidence before rendering the report"
    archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    counts = Counter(c["status"] for c in cases)
    verdict = data["verdict"]
    rows = "".join('<tr><td><a href="scenario-' + str(i) + '.html">' + e(c["id"]) + "</a></td><td>"
                   + e(c["title"]) + "</td><td>" + badge(c["status"], c.get("status_label")) + "</td><td>" + e(c["summary"]) + "</td></tr>"
                   for i, c in enumerate(cases, 1))
    summary = ("<h1>CNTRLPLANE-4338 verification report</h1><p class=\"lead\">" + e(data["summary"])
               + "</p><p>Overall verdict: " + badge(data["functional_verdict"], data.get("verdict_label")) + "</p>"
               + "<p class=\"muted\">Verdict scope: " + e(data["verdict_scope"]) + "</p>"
               + "<h2>1. Report identifier</h2>" + state(data["identifier"])
               + "<h2>2. Summary</h2><div class=\"summary\"><div><strong>9</strong>Scenario groups</div><div><strong>"
               + str(counts["pass"]) + "</strong>Passed</div><div><strong>" + str(counts["blocked"])
               + "</strong>With verification limitation</div><div><strong>" + str(counts["fail"]) + "</strong>Failed</div></div>"
               + chart(counts) + '<p class="muted">Source: recorded outcomes from this execution. TC-PROP-001 propagation passed; exact trigger attribution cannot be proven with existing behavior. Plan v4 requires the formal status blocked for the unproven assertion.</p>'
               + '<h2>3. Variances and qualifications</h2>' + listing(data["variances"])
               + '<h2>4. Comprehensiveness assessment</h2>' + paragraphs(data["comprehensiveness"])
               + '<h2>5. Summary of results</h2><table><thead><tr><th>Case</th><th>Objective</th><th>Result</th><th>Finding</th></tr></thead><tbody>'
               + rows + '</tbody></table><h2>6. Evaluation</h2>' + paragraphs(data["evaluation"])
               + '<h2>7. Summary of activities</h2>' + listing(data["activities"])
               + '<h2>8. Approvals</h2>' + paragraphs(data["approvals"])
               + '<h2>Evidence package</h2><p><a href="cntrlplane-4338-evidence.zip" download>Download the sanitized evidence ZIP</a>. '
               + e(archive.stat().st_size) + ' bytes.</p><p>SHA-256: <code>' + archive_hash + '</code></p>'
               + '<p>Plan: <a href="' + e(data["plan_url"]) + '">version 4 at its recorded revision</a>. '
               + 'Implementation: <a href="https://github.com/openshift/hypershift/pull/9920">PR #9920</a>.</p>')
    (DEST / "index.html").write_text(page("CNTRLPLANE-4338 verification report", summary, data))
    for index, case in enumerate(cases, 1):
        assertions = "".join("<tr><td>" + e(a["claim"]) + "</td><td>" + e(a["expected"])
                             + "</td><td>" + e(a["actual"]) + "</td><td>" + badge(a["status"], a.get("status_label")) + "</td></tr>"
                             for a in case["assertions"])
        body = ("<h1>" + e(case["id"] + ". " + case["title"]) + "</h1><p>" + badge(case["status"], case.get("status_label"))
                + "</p><p class=\"lead\">" + e(case["summary"]) + "</p>"
                + ("<p class=\"muted\">" + e(case["plan_status_note"]) + "</p>" if case.get("plan_status_note") else "")
                + "<h2>Objective</h2><p>" + e(case["objective"])
                + "</p><h2>Preconditions</h2>" + listing(case["preconditions"])
                + "<h2>Execution</h2><ol>" + "".join("<li>" + e(v) + "</li>" for v in case["procedure"]) + "</ol>"
                + '<h2>Before and after evidence</h2><div class="comparison"><section><h3>Before</h3>' + state(case["before"])
                + '</section><section><h3>After</h3>' + state(case["after"]) + '</section></div>'
                + '<h2>Expected and actual results</h2><table><thead><tr><th>Assertion</th><th>Expected</th><th>Actual</th><th>Result</th></tr></thead><tbody>'
                + assertions + '</tbody></table><h2>Restoration and cleanup</h2>' + state(case["cleanup"])
                + '<h2>Evidence inside the ZIP</h2><p><a href="cntrlplane-4338-evidence.zip" download>Evidence ZIP</a> contains these records.</p>'
                + listing(case["evidence"]) + '<h2>Scope and limitations</h2>' + listing(case["limitations"]))
        (DEST / f"scenario-{index}.html").write_text(page(case["id"] + " verification", body, data))
    automated = ("<h1>Automated verification evidence</h1>" + paragraphs(data["automated"]["description"])
                 + state(data["automated"]["results"]) + "<h2>Commands and retained output</h2>"
                 + listing(data["automated"]["evidence"]))
    (DEST / "automated-tests.html").write_text(page("CNTRLPLANE-4338 automated verification", automated, data))
    appendix = ("<h1>Environment and provenance</h1><h2>Environment</h2>" + state(data["environment"])
                + "<h2>Source, build, and running binaries</h2>" + state(data["provenance"])
                + "<h2>Sanitization and evidence integrity</h2>" + paragraphs(data["sanitization"])
                + "<p>Archive SHA-256: <code>" + archive_hash + "</code></p><h2>Validation</h2>" + state(data["validation"])
                + "<h2>Fixture disposition</h2>" + state(data["fixture_disposition"]))
    (DEST / "appendices.html").write_text(page("CNTRLPLANE-4338 environment and provenance", appendix, data))
    metadata = {"jira_key": data["identifier"]["issue"], "format": "html-bundle", "date": data["generated_at"][:10],
                "verdict": verdict, "functional_verdict": data["functional_verdict"],
                "verdict_label": data["verdict_label"], "verdict_scope": data["verdict_scope"],
                "plan_acceptance": data["plan_acceptance"], "scenario_count": 9, "pass_count": counts["pass"],
                "ci_verified": data["ci_verified"], "has_derived_markdown": False, "tester": "Automated verification runner",
                "pr": {"repo": "openshift/hypershift", "number": 9920, "url": "https://github.com/openshift/hypershift/pull/9920"},
                "plan_url": data["plan_url"], "plan_id": "CNTRLPLANE-4338-supplemental-verification", "plan_version": 4,
                "ieee_829": True, "tags": ["global-configuration", "aws", "main-5.1", "supplemental-verification"]}
    (DEST / "metadata.yaml").write_text(yaml.safe_dump(metadata, sort_keys=False))
    print("Rendered nine scenario pages and IEEE summary; verdict:", verdict)


if __name__ == "__main__":
    main()
