#!/usr/bin/env python3
"""Reconstruct exact replay fixtures from pinned public source and verify hashes."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

PREFIX = Path("control-plane-operator/hostedclusterconfigoperator/controllers/resources")
HERE = Path(__file__).resolve().parent


def restore(checkout, output, manifest_path):
    manifest = json.loads(manifest_path.read_text())
    revision = manifest["head_revision"]
    subprocess.run(["git", "cat-file", "-e", revision + "^{commit}"], cwd=checkout, check=True)
    output.mkdir(parents=True, exist_ok=False)
    head = output / "source/hypershift-pr" / PREFIX
    base = output / "source/hypershift-baseline" / PREFIX
    (head / "configuration").mkdir(parents=True)
    base.mkdir(parents=True)
    paths = {item["relative_path"] for item in manifest["fixtures"] if item["flavor"] == "hypershift-pr"}
    paths.update(["configuration/adapters.go", "configuration/inputs.go"])
    for relative in sorted(paths):
        raw = subprocess.check_output(["git", "show", revision + ":" + str(PREFIX / relative)], cwd=checkout)
        target = head / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    subprocess.run([sys.executable, str(HERE / "prepare_retrospective.py"), "--root", str(output)], check=True)
    for item in manifest["fixtures"]:
        if item["flavor"] != "hypershift-baseline" or item["relative_path"].startswith("retrospective") or item["relative_path"] == "foundation_order_test.go":
            continue
        raw = subprocess.check_output(["git", "show", manifest["baseline_revision"] + ":" + str(PREFIX / item["relative_path"])], cwd=checkout)
        target = base / item["relative_path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    verified = []
    for item in manifest["fixtures"]:
        path = output / "source" / item["flavor"] / PREFIX / item["relative_path"]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != item["original_sha256"]:
            raise RuntimeError("Original fixture hash mismatch: " + item["archive_path"])
        verified.append({"archive_path": item["archive_path"], "original_sha256": digest})
    (output / "verified-fixtures.json").write_text(json.dumps(verified, indent=2))
    print("Reconstructed and verified", len(verified), "exact original fixtures.")
    print("Use these reconstructed test files with the pinned head/baseline checkouts; do not overlay the transformed evidence copies.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--head-checkout", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--manifest", type=Path, default=HERE.parent / "source/replay-manifest.json")
    args = parser.parse_args()
    restore(args.head_checkout.resolve(), args.output.resolve(), args.manifest.resolve())
