#!/usr/bin/env python3
"""Index actual verbose Go test outcomes and pair retrospective fixtures."""
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent


def parse(name):
    events, pending = [], []
    packages = []
    for line in (root / "private" / name).read_text().splitlines():
        match = re.match(r"\s*--- (PASS|FAIL|SKIP): (\S+) \(([^)]+)\)", line)
        if match:
            pending.append({"result": match[1], "test": match[2], "elapsed": match[3]})
        package = re.match(r"^(ok|FAIL)\s+(github\.com/\S+)(.*)$", line)
        if package:
            for event in pending:
                event["package"] = package[2]
            events.extend(pending)
            pending = []
            packages.append({"package": package[2], "result": package[1], "details": package[3].strip()})
    return {"log": name, "events": events, "packages": packages}


head = parse("pr-unit-verbose.log")
base = parse("baseline-unit-retry.log")
inputs = parse("baseline-inputs-focused.log")
base["events"].extend(inputs["events"])
functions = {"TestReconcileGlobal", "TestReconcileImagePolicy", "TestReconcileInstallMetadata",
             "TestReconcileObserved", "TestReconcileProxyTrustedCA", "TestReconcileProxyCABundle"}
head_cases = {e["test"]: e for e in head["events"]
              if e["test"].split("/")[0] in functions and e["package"].endswith("/configuration")}
base_cases = {e["test"].replace("TestRetrospective", "Test", 1): e for e in base["events"]
              if e["test"].startswith("TestRetrospective")}
comparison = [{"test": name, "before": base_cases.get(name), "after": event,
               "paired_pass": bool(base_cases.get(name)) and base_cases[name]["result"] == event["result"] == "PASS"}
              for name, event in sorted(head_cases.items())]
result = {"base_revision": "b0edc822e1ffb9f0527091a764d940b81b2c34a8",
          "head_revision": "d037aa90aa5b889c69464004df2e74f4c4c5b287",
          "evidence_type": "Retrospective equivalence; not proof of historical execution timing",
          "head": head, "base": base, "paired_characterization": comparison,
          "new_input_api_tests": [e for e in head["events"] if e["test"].split("/")[0] == "TestProxyParamsFor"],
          "new_input_api_qualification": "ProxyParamsFor did not exist before extraction. Its head tests are new-API evidence, not retrospective old-implementation comparisons.",
          "all_paired_cases_pass": bool(comparison) and all(c["paired_pass"] for c in comparison)}
destination = root / "evidence" / "unit-results.json"
destination.write_text(json.dumps(result, indent=2))
unit_directory = root / "evidence/unit"
unit_directory.mkdir(exist_ok=True)
for label, run in [("head", head), ("baseline", base)]:
    suites = ET.Element("testsuites", {"name": "CNTRLPLANE-4338 " + label})
    for package in run["packages"]:
        events = [event for event in run["events"] if event["package"] == package["package"]]
        leaves = [event for event in events if not any(other["test"].startswith(event["test"] + "/") for other in events)]
        suite = ET.SubElement(suites, "testsuite", {"name": package["package"], "tests": str(len(leaves)),
                              "failures": str(sum(e["result"] == "FAIL" for e in leaves)),
                              "skipped": str(sum(e["result"] == "SKIP" for e in leaves))})
        for event in leaves:
            case = ET.SubElement(suite, "testcase", {"classname": package["package"], "name": event["test"],
                                 "time": event["elapsed"].removesuffix("s")})
            if event["result"] == "FAIL":
                ET.SubElement(case, "failure", {"message": "See retained verbose log for assertion output"})
            elif event["result"] == "SKIP":
                ET.SubElement(case, "skipped")
        ET.SubElement(suite, "system-out").text = "Derived from actual retained verbose Go output: " + run["log"]
    ET.indent(suites)
    ET.ElementTree(suites).write(unit_directory / (label + "-junit.xml"), encoding="utf-8", xml_declaration=True)
print("Paired characterization outcomes:", len(comparison), "all pass:", result["all_paired_cases_pass"])
print("Unpaired cases:", [c["test"] for c in comparison if not c["paired_pass"]])
print("Head package results:", len(head["packages"]), "baseline package results:", len(base["packages"]))
