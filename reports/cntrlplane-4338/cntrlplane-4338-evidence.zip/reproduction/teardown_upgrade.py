#!/usr/bin/env python3
"""Inventory and normally destroy only the completed disposable upgrade fixture."""
import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "private/upgrade-cleanup"
NAME = "hc-4338-upgrade"
NS = "clusters-" + NAME
ENV = dict(os.environ, AWS_SHARED_CREDENTIALS_FILE=str(ROOT / "private/aws-provisioning.ini"),
           KUBECONFIG="/work/operator/aws_dev_kubeconfig", AWS_PAGER="")


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def save(name, value):
    OUT.mkdir(exist_ok=True)
    (OUT / (name + ".json")).write_text(json.dumps(value, indent=2))


def query(command):
    p = subprocess.run(command, capture_output=True, text=True, env=ENV, timeout=120)
    if p.returncode:
        raise RuntimeError(p.stderr)
    return json.loads(p.stdout) if p.stdout.strip() else None


def aws(service, operation, *args):
    return query(["aws", service, operation, "--region", "us-east-1", "--output", "json", *args])


def oc(*args):
    return query(["oc", "--kubeconfig", ENV["KUBECONFIG"], "--request-timeout=30s", *args, "-o", "json"])


def inventory(hc):
    vpc = hc["spec"]["platform"]["aws"]["cloudProviderConfig"]["vpc"]
    infra = hc["spec"]["infraID"]
    result = {"observed_at": now(), "hc_uid": hc["metadata"]["uid"], "infra_id": infra, "vpc_id": vpc}
    filters = ["Name=vpc-id,Values=" + vpc]
    for operation, key in [("describe-vpcs", "Vpcs"), ("describe-subnets", "Subnets"),
                           ("describe-security-groups", "SecurityGroups"), ("describe-route-tables", "RouteTables"),
                           ("describe-network-interfaces", "NetworkInterfaces"), ("describe-vpc-endpoints", "VpcEndpoints"),
                           ("describe-nat-gateways", "NatGateways"), ("describe-instances", "Reservations")]:
        result[key] = aws("ec2", operation, "--filters" if operation != "describe-nat-gateways" else "--filter", *filters)[key]
    result["InternetGateways"] = aws("ec2", "describe-internet-gateways", "--filters", "Name=attachment.vpc-id,Values=" + vpc)["InternetGateways"]
    services = oc("get", "services", "-n", NS)
    result["ControlPlaneServices"] = services
    service_hosts = {x["hostname"] for s in services["items"] for x in s.get("status", {}).get("loadBalancer", {}).get("ingress", []) if x.get("hostname")}
    result["LoadBalancersV2"] = [x for x in aws("elbv2", "describe-load-balancers")["LoadBalancers"] if x["VpcId"] == vpc or x["DNSName"] in service_hosts]
    result["LoadBalancersClassic"] = [x for x in aws("elb", "describe-load-balancers")["LoadBalancerDescriptions"] if x.get("VPCId") == vpc or x["DNSName"] in service_hosts]
    loadbalancer_arns = {x["LoadBalancerArn"] for x in result["LoadBalancersV2"]}
    result["TargetGroups"] = [x for x in aws("elbv2", "describe-target-groups")["TargetGroups"] if x.get("VpcId") == vpc or loadbalancer_arns.intersection(x.get("LoadBalancerArns", []))]
    result["PrivateZones"] = aws("route53", "list-hosted-zones-by-vpc", "--vpc-id", vpc, "--vpc-region", "us-east-1")["HostedZoneSummaries"]
    result["Roles"] = [x for x in aws("iam", "list-roles")["Roles"] if x["RoleName"].startswith(infra)]
    result["InstanceProfiles"] = [x for x in aws("iam", "list-instance-profiles")["InstanceProfiles"] if x["InstanceProfileName"].startswith(infra)]
    result["OIDCProviders"] = [x for x in aws("iam", "list-open-id-connect-providers")["OpenIDConnectProviderList"] if infra in x["Arn"]]
    ids = {x["InstanceId"] for r in result["Reservations"] for x in r["Instances"]}
    result["Volumes"] = [x for x in aws("ec2", "describe-volumes")["Volumes"]
                         if any(a.get("InstanceId") in ids for a in x.get("Attachments", []))
                         or any(infra in str(t) for t in x.get("Tags", []))]
    interfaces = {x["NetworkInterfaceId"] for x in result["NetworkInterfaces"]}
    result["Addresses"] = [x for x in aws("ec2", "describe-addresses")["Addresses"]
                           if x.get("NetworkInterfaceId") in interfaces or any(infra in str(t) for t in x.get("Tags", []))]
    guest_registry = query(["oc", "--kubeconfig", str(ROOT / "private/upgrade-lifecycle/guest.kubeconfig"),
                            "get", "configs.imageregistry.operator.openshift.io", "cluster", "-o", "json"])
    result["RegistryConfig"] = guest_registry
    result["RegistryBuckets"] = sorted({guest_registry.get(k, {}).get("storage", {}).get("s3", {}).get("bucket")
                                        for k in ["spec", "status"]} - {None, ""})
    # The OIDC bucket itself is shared; only this fixture's exact issuer prefix is owned.
    from urllib.parse import urlparse
    issuer = urlparse(hc["spec"]["issuerURL"])
    host = issuer.hostname or ""
    if ".s3" in host and host.endswith(".amazonaws.com"):
        result["OIDCStorage"] = {"bucket": host.split(".s3")[0], "prefix": issuer.path.strip("/") + "/"}
        assert infra in result["OIDCStorage"]["prefix"] and result["OIDCStorage"]["prefix"] != "/"
    else:
        raise RuntimeError("Resolve exact OIDC storage ownership before cleanup")
    result["OIDCObjects"] = aws("s3api", "list-objects-v2", "--bucket", result["OIDCStorage"]["bucket"], "--prefix", result["OIDCStorage"]["prefix"]).get("Contents", [])
    return result


def verify(before):
    # Query exact pre-deletion identities, including resources that can become detached.
    result = {"checked_at": now(), "checks": {}}
    checks = result["checks"]
    for kind, args in {
        "hostedcluster_absent": ("get", "hc", NAME, "-n", "clusters", "--ignore-not-found"),
        "hostedcontrolplane_namespace_absent": ("get", "namespace", NS, "--ignore-not-found"),
    }.items():
        checks[kind] = oc(*args) is None
    checks["selected_nodepools_absent"] = not any(p["spec"]["clusterName"] == NAME for p in oc("get", "np", "-n", "clusters")["items"])
    checks["controlplane_claim_volumes_absent"] = not any(p.get("spec", {}).get("claimRef", {}).get("namespace") == NS for p in oc("get", "pv")["items"])
    for operation, key, id_key, filter_key in [
        ("describe-vpcs", "Vpcs", "VpcId", "vpc-id"),
        ("describe-subnets", "Subnets", "SubnetId", "subnet-id"),
        ("describe-security-groups", "SecurityGroups", "GroupId", "group-id"),
        ("describe-route-tables", "RouteTables", "RouteTableId", "route-table-id"),
        ("describe-network-interfaces", "NetworkInterfaces", "NetworkInterfaceId", "network-interface-id"),
        ("describe-internet-gateways", "InternetGateways", "InternetGatewayId", "internet-gateway-id"),
        ("describe-vpc-endpoints", "VpcEndpoints", "VpcEndpointId", "vpc-endpoint-id"),
        ("describe-volumes", "Volumes", "VolumeId", "volume-id"),
        ("describe-addresses", "Addresses", "AllocationId", "allocation-id"),
    ]:
        ids = [x[id_key] for x in before[key]]
        remaining = aws("ec2", operation, "--filters", "Name=" + filter_key + ",Values=" + ",".join(ids))[key] if ids else []
        result[key] = remaining
        checks[key + "_absent"] = not remaining
    nats = aws("ec2", "describe-nat-gateways", "--filter", "Name=nat-gateway-id,Values=" + ",".join(x["NatGatewayId"] for x in before["NatGateways"]))["NatGateways"] if before["NatGateways"] else []
    result["NatGateways"] = nats
    checks["nat_gateways_absent_or_deleted"] = all(x["State"] == "deleted" for x in nats)
    ids = [x["InstanceId"] for r in before["Reservations"] for x in r["Instances"]]
    instances = aws("ec2", "describe-instances", "--filters", "Name=instance-id,Values=" + ",".join(ids))["Reservations"] if ids else []
    result["Instances"] = instances
    checks["instances_absent_or_terminated"] = all(x["State"]["Name"] == "terminated" for r in instances for x in r["Instances"])
    for service, operation, key, before_key, id_key in [
        ("elbv2", "describe-load-balancers", "LoadBalancers", "LoadBalancersV2", "LoadBalancerArn"),
        ("elb", "describe-load-balancers", "LoadBalancerDescriptions", "LoadBalancersClassic", "LoadBalancerName"),
        ("elbv2", "describe-target-groups", "TargetGroups", "TargetGroups", "TargetGroupArn"),
        ("iam", "list-roles", "Roles", "Roles", "Arn"),
        ("iam", "list-instance-profiles", "InstanceProfiles", "InstanceProfiles", "Arn"),
        ("iam", "list-open-id-connect-providers", "OpenIDConnectProviderList", "OIDCProviders", "Arn"),
        ("route53", "list-hosted-zones", "HostedZones", "PrivateZones", "HostedZoneId"),
    ]:
        live = aws(service, operation)[key]
        if before_key == "PrivateZones":
            present = {x["Id"].split("/")[-1] for x in live}
            retained = [x for x in before[before_key] if x[id_key].split("/")[-1] in present]
        else:
            present = {x[id_key] for x in live}
            retained = [x for x in before[before_key] if x[id_key] in present]
        result[before_key] = retained
        checks[before_key + "_absent"] = not retained
    buckets = {x["Name"] for x in aws("s3api", "list-buckets")["Buckets"]}
    result["RegistryBucketsRemaining"] = [name for name in before["RegistryBuckets"] if name in buckets]
    checks["owned_registry_buckets_absent"] = not result["RegistryBucketsRemaining"]
    oidc = before["OIDCStorage"]
    result["OIDCObjectsRemaining"] = aws("s3api", "list-objects-v2", "--bucket", oidc["bucket"], "--prefix", oidc["prefix"]).get("Contents", [])
    checks["owned_oidc_objects_absent"] = not result["OIDCObjectsRemaining"]
    result["all_checks_passed"] = all(checks.values())
    return result


def main():
    os.umask(0o077)
    hc_path = OUT / "hostedcluster-before.json"
    hc = json.loads(hc_path.read_text()) if hc_path.exists() else oc("get", "hc", NAME, "-n", "clusters")
    assert hc["metadata"]["name"] == NAME
    assert hc["metadata"].get("annotations", {}).get("hypershift.openshift.io/skip-delete-hosted-controlplane-namespace") != "true"
    if "--inventory" in sys.argv:
        save("aws-before", inventory(hc))
        print("Scoped AWS pre-deletion inventory saved.", flush=True)
        return
    case = ROOT / "private/live" / NAME / "TC-REG-007B/assertions.json"
    assert json.loads(case.read_text())["result"] == "pass", "The live upgrade must finish before cleanup"
    current = oc("get", "hc", NAME, "-n", "clusters")
    assert current["metadata"]["uid"] == hc["metadata"]["uid"], "Fixture identity changed"
    save("hostedcluster-at-deletion", current)
    before = inventory(hc)
    save("aws-before", before)
    command = ["/work/operator/test-operator/hypershift_ws/hypershift/bin/hypershift", "destroy", "cluster", "aws",
               "--name", NAME, "--namespace", "clusters", "--region", "us-east-1", "--aws-creds", ENV["AWS_SHARED_CREDENTIALS_FILE"]]
    save("command", {"started_at": now(), "arguments": command, "hc_uid": hc["metadata"]["uid"], "normal_cleanup": True})
    print("Destroying only the completed disposable upgrade fixture through normal cleanup.", flush=True)
    with (OUT / "destroy.log").open("w") as stream:
        result = subprocess.run(command, env=ENV, stdout=stream, stderr=subprocess.STDOUT, timeout=5400)
    save("command-result", {"completed_at": now(), "exit_code": result.returncode})
    assert result.returncode == 0, "Normal destroy command failed; inspect the restricted log"
    for attempt in range(8):
        after = verify(before)
        save("independent-verification", after)
        if after["all_checks_passed"]:
            record = json.loads(case.read_text())
            record["normal_fixture_cleanup"] = "pass"
            record["cleanup_completed_at"] = now()
            case.write_text(json.dumps(record, indent=2))
            print("Independent Kubernetes and exact-identity AWS cleanup checks passed.", flush=True)
            return
        time.sleep(20)
    raise RuntimeError("Destroy returned successfully but independent cleanup verification has remaining resources")


if __name__ == "__main__":
    main()
