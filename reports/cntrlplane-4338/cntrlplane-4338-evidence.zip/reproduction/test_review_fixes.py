#!/usr/bin/env python3
"""Offline regressions for evidence sanitization and propagation result recording."""
import copy
import json
from pathlib import Path
import re
import tempfile
import unittest
from unittest.mock import Mock, patch

import live_tests
from package_evidence import sanitize_text


class EvidenceSanitization(unittest.TestCase):
    def test_aws_identity_and_compute_hosts_are_pseudonymized_consistently(self):
        role = "AROA" + "ABCDEFGHIJKLMNOPQ"
        profile = "AIPA" + "ABCDEFGHIJKLMNOPQ"
        reservation = "r-" + "0123456789abcdef0"
        instance_host = "-".join(["ec2", "198", "18", "1", "7"])
        host = instance_host + ".compute-1.amazonaws.com"
        regional = instance_host + ".eu-west-1.compute.amazonaws.com"
        value = {"RoleId": role, "InstanceProfileId": profile,
                 "Reservations": [{"ReservationId": reservation, "Instances": [{"IamInstanceProfile": {"Id": profile},
                     "PublicDnsName": host, "PublicIpv4DnsName": host}]}], "RegionalDnsName": regional}
        encoded = sanitize_text(json.dumps(value))
        result = json.loads(encoded)
        for original in [role, profile, reservation, host, regional]:
            self.assertNotIn(original, encoded)
        instance = result["Reservations"][0]["Instances"][0]
        self.assertEqual(result["InstanceProfileId"], instance["IamInstanceProfile"]["Id"])
        self.assertEqual(instance["PublicDnsName"], instance["PublicIpv4DnsName"])
        self.assertEqual(encoded, sanitize_text(json.dumps(value)))


class PropagationResultRecording(unittest.TestCase):
    def exercise(self, failure=None):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        run = live_tests.Run.__new__(live_tests.Run)
        run.directory = Path(temporary.name)
        (run.directory / "TC-PROP-001").mkdir()
        run.guest = run.directory / "unused-kubeconfig"
        cm = {"data": {"config": json.dumps({"spec": {}})}}
        before = {"build": {"spec": {}}, "project": {"spec": {}}, "observed-build": cm, "observed-project": cm}
        def observed(phase):
            result = copy.deepcopy(before)
            if failure == "counterpart" and phase.endswith("after-build"):
                result["observed-project"]["data"]["config"] = json.dumps({"spec": {"unexpected": "change"}})
            return result
        def wait(label, check, **kwargs):
            if label == failure:
                raise AssertionError("injected " + label)
            return True
        run.observed = Mock(side_effect=observed)
        run.patch = Mock(side_effect=lambda *args, **kwargs: {"spec": args[3]["spec"]})
        run.wait = Mock(side_effect=wait)
        run.get = Mock(return_value={"spec": {}})
        run.oc = Mock()
        observers = []
        def process(*args, **kwargs):
            handle = Mock()
            observers.append((handle, kwargs["stdout"], kwargs["stderr"]))
            return handle
        with patch.object(live_tests.subprocess, "Popen", side_effect=process), patch.object(live_tests.time, "sleep"):
            if failure:
                with self.assertRaises(AssertionError):
                    run.propagation()
            else:
                run.propagation()
        for handle, out, err in observers:
            out.close()
            err.close()
        result = run.directory / "TC-PROP-001/assertions.json"
        if failure:
            self.assertFalse(result.exists(), "A failed check must never leave a successful assertion artifact")
        else:
            self.assertEqual(json.loads(result.read_text())["propagation_routing_ownership_and_restoration"], "pass")
        if failure != "build-restoration":
            self.assertEqual(run.oc.call_count, 2, "Both original source specs must be restored")

    def test_success_requires_mutations_and_restoration(self):
        self.exercise()

    def test_projection_failure_restores_without_publishing_pass(self):
        self.exercise("build-projection")

    def test_counterpart_failure_restores_without_publishing_pass(self):
        self.exercise("counterpart")

    def test_restoration_failure_does_not_publish_pass(self):
        self.exercise("build-restoration")


if __name__ == "__main__":
    unittest.main(verbosity=2)
