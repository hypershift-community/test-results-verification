#!/usr/bin/env python3
"""TC-REG-007B: retain a pre-PR install version through a real release upgrade."""
import copy
import json
import os
from pathlib import Path
import time

from live_tests import ROOT, NS, Run, now
from validate_release_pair import validate


def main():
    os.umask(0o077)
    previous = json.loads((ROOT / "private/previous-release.json").read_text())
    target = json.loads((ROOT / "private/target-release.json").read_text())
    validate(previous, target)
    images = {i["flavor"]: i for i in json.loads((ROOT / "private/built-images.json").read_text())}
    run = Run("hc-4338-upgrade", "upgrade-lifecycle")
    baseline_image, pr_image = images["baseline"]["image"], images["pr"]["image"]
    previous_version, target_version = previous["metadata"]["version"], target["metadata"]["version"]
    hc = run.get("management", "hc", run.name, NS)
    assert hc["metadata"]["annotations"]["hypershift.openshift.io/control-plane-operator-image"] == baseline_image
    run.readiness("TC-REG-007B/healthy-previous-release-before-pr", previous_version)
    run.provenance("TC-REG-007B/baseline-source-before-pr", baseline_image)
    run.connectivity("TC-REG-007B/before-upgrade")
    initial = run.get("guest", "cm", "openshift-install", "openshift-config")
    run.save("TC-REG-007B/before-pr", "original-install-metadata", initial)
    assert initial.get("data", {}).get("version") == previous_version
    assert initial["data"].get("invoker") == "hypershift"
    assert initial["data"]["version"] != target_version
    # Add an unrelated data entry without touching the original version or invoker.
    run.patch("guest", "cm", "openshift-install", {"data": {"verification-unowned": "cntrlplane-4338-preserve"}}, "openshift-config")
    baseline = run.get("guest", "cm", "openshift-install", "openshift-config")
    assert baseline["data"]["version"] == initial["data"]["version"]
    run.save("TC-REG-007B/before-pr", "baseline-with-unrelated-entry", baseline)
    run.save("TC-REG-007B/before-pr", "baseline-capture", {"captured_at": now(), "source_revision": images["baseline"]["source_revision"],
             "image": baseline_image, "original_install_version": baseline["data"]["version"],
             "target_release_component_version": target_version, "versions_differ": True,
             "pr_implementation_has_not_run_on_fixture": True})
    print("Baseline preserved outside the cluster; beginning the PR release upgrade.", flush=True)
    target_image = "quay.io/openshift-release-dev/ocp-release-nightly@" + target["listDigest"]
    run.patch("management", "hc", run.name, {"metadata": {"annotations": {
        "hypershift.openshift.io/control-plane-operator-image": pr_image}},
        "spec": {"release": {"image": target_image}}}, NS)
    for pool in run.get("management", "np", namespace=NS)["items"]:
        if pool["spec"]["clusterName"] == run.name:
            run.patch("management", "np", pool["metadata"]["name"], {"spec": {"release": {"image": target_image}}}, NS)
    def image_active():
        run.provenance("TC-REG-007B/changed-code-active", pr_image)
        return True
    run.wait("upgrade-pr-image-active", image_active, timeout=900, interval=15)
    early = run.get("guest", "cm", "openshift-install", "openshift-config")
    run.save("TC-REG-007B/after-pr-first-reconcile", "install-metadata", early)
    assert early["data"]["version"] == baseline["data"]["version"]
    run.readiness("TC-REG-007B/upgrade-complete", target_version)
    run.provenance("TC-REG-007B/upgrade-complete", pr_image)
    run.connectivity("TC-REG-007B/upgrade-complete")
    after = run.get("guest", "cm", "openshift-install", "openshift-config")
    run.save("TC-REG-007B/upgrade-complete", "install-metadata", after)
    assert after["data"]["version"] == baseline["data"]["version"]
    assert after["data"]["version"] != target_version
    for key, value in baseline["data"].items():
        assert after["data"].get(key) == value
    run.save("TC-REG-007B", "assertions", {"result": "pass", "completed_at": now(),
             "baseline_release": previous_version, "target_release": target_version,
             "before_data": baseline["data"], "after_data": after["data"],
             "baseline_saved_before_pr_deployment": True, "runtime_source_verified": True,
             "all_readiness_and_connectivity_gates_passed": True,
             "normal_fixture_cleanup": "pending"})
    print("TC-REG-007B assertions passed; disposable fixture awaits normal teardown.", flush=True)


if __name__ == "__main__":
    main()
