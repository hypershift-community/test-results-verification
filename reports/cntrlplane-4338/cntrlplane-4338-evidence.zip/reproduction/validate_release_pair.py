#!/usr/bin/env python3
"""Reject a verification target that does not match the pinned main minor/architecture."""
import argparse
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent


def validate(previous, target):
    source = (ROOT / "source/hypershift-pr/support/supportedversion/version.go").read_text()
    match = re.search(r'LatestSupportedVersion\s*=\s*semver.MustParse\("(\d+)\.(\d+)\.\d+"\)', source)
    if not match:
        raise ValueError("Cannot establish the pinned source's latest supported minor")
    expected = tuple(map(int, match.groups()))
    selected = tuple(map(int, target["metadata"]["version"].split(".")[:2]))
    if selected != expected:
        raise ValueError("Target release must match pinned main " + ".".join(map(str, expected)))
    for label, release in [("previous", previous), ("target", target)]:
        if release["config"]["architecture"] != "amd64":
            raise ValueError(label + " metadata must be resolved explicitly for linux/amd64")
        if not release.get("listDigest"):
            raise ValueError(label + " must retain the selected multi-architecture index digest")
    before = tuple(map(int, previous["metadata"]["version"].split(".")[:2]))
    if not before < selected:
        raise ValueError("The baseline must precede the target minor")
    return {"main_minor": ".".join(map(str, expected)), "architecture": "amd64",
            "previous": previous["metadata"]["version"], "target": target["metadata"]["version"],
            "multi_arch_index_digests_preserved": True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--previous", type=Path, default=ROOT / "private/previous-release.json")
    parser.add_argument("--target", type=Path, default=ROOT / "private/target-release.json")
    args = parser.parse_args()
    try:
        result = validate(json.loads(args.previous.read_text()), json.loads(args.target.read_text()))
    except ValueError as error:
        raise SystemExit(str(error))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
