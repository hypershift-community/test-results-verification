#!/usr/bin/env python3
"""Complete plan TC-REG-002 step 2 with a test-only Go source overlay."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "evidence/unit/tc-reg-002-stability"
PREFIX = Path("control-plane-operator/hostedclusterconfigoperator/controllers/resources")
NAME = "When image content sources remain removed, it should preserve the empty IDMS"
MARKER = "TC_REG_002_STATES "
BLOCK = '''
	t.Run("When image content sources remain removed, it should preserve the empty IDMS", func(t *testing.T) {
		g := NewWithT(t)
		hcp := configurationHCP(withGlobalConfiguration)
		guest := fake.NewClientBuilder().WithScheme(api.Scheme).Build()
		root := &configurationTestClients{client: guest, CreateOrUpdateProvider: &simpleCreateOrUpdater{}}
		g.Expect(ReconcileImagePolicy(t.Context(), root.hosted(), hcp.Spec.ImageContentSources)).To(Succeed())
		configured := globalconfig.ImageDigestMirrorSet()
		g.Expect(guest.Get(t.Context(), client.ObjectKeyFromObject(configured), configured)).To(Succeed())
		g.Expect(configured.Spec.ImageDigestMirrors).ToNot(BeEmpty())
		g.Expect(configured.Labels).To(HaveKeyWithValue("machineconfiguration.openshift.io/role", "worker"))

		g.Expect(ReconcileImagePolicy(t.Context(), root.hosted(), nil)).To(Succeed())
		removed := globalconfig.ImageDigestMirrorSet()
		g.Expect(guest.Get(t.Context(), client.ObjectKeyFromObject(removed), removed)).To(Succeed())
		g.Expect(removed.Spec.ImageDigestMirrors).To(BeEmpty())
		g.Expect(removed.Labels).To(HaveKeyWithValue("machineconfiguration.openshift.io/role", "worker"))
		beforeRepeat := removed.DeepCopy()

		g.Expect(ReconcileImagePolicy(t.Context(), root.hosted(), nil)).To(Succeed())
		repeated := globalconfig.ImageDigestMirrorSet()
		g.Expect(guest.Get(t.Context(), client.ObjectKeyFromObject(repeated), repeated)).To(Succeed())
		g.Expect(repeated.Spec.ImageDigestMirrors).To(BeEmpty())
		g.Expect(repeated).To(Equal(beforeRepeat))

		states, err := json.Marshal(map[string]any{
			"configured": configured, "after_removal": beforeRepeat, "after_repeated_removal": repeated,
		})
		g.Expect(err).ToNot(HaveOccurred())
		t.Logf("TC_REG_002_STATES %s", states)
	})
'''


def run(label):
    baseline = label == "baseline"
    checkout = ROOT / "source" / ("hypershift-baseline" if baseline else "hypershift-pr")
    relative = PREFIX / ("retrospective_image_policy_test.go" if baseline else "configuration/image_policy_test.go")
    original = checkout / relative
    source = original.read_text()
    helper = "retrospectiveCompareICSAndIDMS" if baseline else "compareICSAndIDMS"
    anchor = "\n}\n\nfunc " + helper
    assert source.count(anchor) == 1
    assert '"encoding/json"' not in source
    augmented = source.replace('"context"', '"context"\n\t"encoding/json"', 1)
    augmented = augmented.replace(anchor, "\n" + BLOCK + anchor, 1)
    directory = OUTPUT / label
    directory.mkdir(parents=True, exist_ok=True)
    overlay_source = directory / "image_policy_test.go"
    overlay_source.write_text(augmented)
    subprocess.run(["gofmt", "-w", str(overlay_source)], check=True)
    overlay = directory / "overlay.json"
    overlay.write_text(json.dumps({"Replace": {str(original): str(overlay_source)}}, indent=2))
    function = "TestRetrospectiveReconcileImagePolicy" if baseline else "TestReconcileImagePolicy"
    package = "./" + str(PREFIX) + ("" if baseline else "/configuration")
    selector = "^" + function + "$/^" + NAME.replace(" ", "_") + "$"
    command = ["go", "test", "-mod=vendor", "-race", "-count=1", "-p=2", "-v", "-json",
               "-timeout=10m", "-overlay", str(overlay), "-run", selector, package]
    metadata = {"revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip(),
                "command": command, "started_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                "original_fixture": str(relative), "original_fixture_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
                "overlay_fixture_sha256": hashlib.sha256(overlay_source.read_bytes()).hexdigest(),
                "scope": "Supplemental execution of existing plan TC-REG-002 step 2; original fixture and product files unchanged."}
    env = dict(os.environ, GOMAXPROCS="4", GOTOOLCHAIN="auto", GOPROXY="off")
    result = subprocess.run(command, cwd=checkout, env=env, capture_output=True, text=True, timeout=660)
    (directory / "go-test.jsonl").write_text(result.stdout)
    (directory / "go-test.stderr").write_text(result.stderr)
    events = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
    (directory / "verbose.log").write_text("".join(e.get("Output", "") for e in events))
    metadata.update(completed_at=dt.datetime.now(dt.timezone.utc).isoformat(), exit_status=result.returncode)
    (directory / "execution.json").write_text(json.dumps(metadata, indent=2))
    assert result.returncode == 0, "Focused test failed; inspect retained output in " + str(directory)
    leaves = [e for e in events if e.get("Action") == "pass" and e.get("Test") == function + "/" + NAME.replace(" ", "_")]
    assert len(leaves) == 1
    assert not any(e.get("Action") in {"fail", "skip"} for e in events)
    captures = [json.loads(e["Output"].split(MARKER, 1)[1]) for e in events if MARKER in e.get("Output", "")]
    assert len(captures) == 1
    states = captures[0]
    assert states["configured"]["spec"]["imageDigestMirrors"]
    assert not states["after_removal"]["spec"].get("imageDigestMirrors")
    assert states["after_removal"] == states["after_repeated_removal"]
    assert hashlib.sha256(original.read_bytes()).hexdigest() == metadata["original_fixture_sha256"]
    (directory / "states.json").write_text(json.dumps(states, indent=2))
    suite = ET.Element("testsuite", {"name": leaves[0]["Package"], "tests": "1", "failures": "0", "skipped": "0"})
    ET.SubElement(suite, "testcase", {"name": leaves[0]["Test"], "classname": leaves[0]["Package"], "time": str(leaves[0]["Elapsed"])})
    ET.ElementTree(suite).write(directory / "junit.xml", encoding="utf-8", xml_declaration=True)
    print(label, "PASS: populated IDMS cleared, then unchanged after repeated removal reconciliation.")


def summarize():
    runs = {}
    for label in ["baseline", "head"]:
        directory = OUTPUT / label
        metadata = json.loads((directory / "execution.json").read_text())
        assert metadata["exit_status"] == 0
        runs[label] = {"execution": metadata, "states": json.loads((directory / "states.json").read_text())}
    assert runs["baseline"]["execution"]["revision"] == "b0edc822e1ffb9f0527091a764d940b81b2c34a8"
    assert runs["head"]["execution"]["revision"] == "d037aa90aa5b889c69464004df2e74f4c4c5b287"
    for phase in ["configured", "after_removal", "after_repeated_removal"]:
        assert runs["baseline"]["states"][phase] == runs["head"]["states"][phase]
    summary = {"plan_case": "TC-REG-002", "plan_step": 2, "result": "pass",
               "scope": "One additional paired leaf check, executed after report review; separate from the original 50 paired parent/subtest outcomes and 19-package regressions.",
               "all_three_states_match_across_revisions": True, "runs": runs}
    (OUTPUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("Supplemental baseline/head stability check PASS; original evidence retained unchanged.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["baseline", "head", "summary"])
    args = parser.parse_args()
    summarize() if args.action == "summary" else run(args.action)
