package resources

import (
	"context"
	configv1 "github.com/openshift/api/config/v1"
	hyperv1 "github.com/openshift/hypershift/api/hypershift/v1beta1"
	"github.com/openshift/hypershift/support/releaseinfo"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	utilerrors "k8s.io/apimachinery/pkg/util/errors"
)

func legacyRoot(hosted HostedCluster, controlPlane ControlPlane) *reconciler {
	return &reconciler{client: hosted.client, cpClient: controlPlane.client,
		CreateOrUpdateProvider: configurationUpserter{hosted.createOrUpdate}}
}

func ReconcileGlobal(ctx context.Context, hosted HostedCluster, cp ControlPlane, hcp *hyperv1.HostedControlPlane) error {
	return legacyRoot(hosted, cp).reconcileConfig(ctx, hcp)
}

func ReconcileImagePolicy(ctx context.Context, hosted HostedCluster, sources []hyperv1.ImageContentSource) error {
	return legacyRoot(hosted, ControlPlane{}).reconcileImageContentPolicyType(ctx,
		&hyperv1.HostedControlPlane{Spec: hyperv1.HostedControlPlaneSpec{ImageContentSources: sources}})
}

func ReconcileInstallMetadata(ctx context.Context, hosted HostedCluster, release *releaseinfo.ReleaseImage) error {
	return legacyRoot(hosted, ControlPlane{}).reconcileInstallConfigMap(ctx, release)
}

func ReconcileObserved(ctx context.Context, hosted HostedCluster, cp ControlPlane, params ObservedConfigParams) error {
	hcp := &hyperv1.HostedControlPlane{ObjectMeta: metav1.ObjectMeta{
		Namespace: params.Namespace, Name: params.OwnerRef.Reference.Name, UID: params.OwnerRef.Reference.UID}}
	return utilerrors.NewAggregate(legacyRoot(hosted, cp).reconcileObservedConfiguration(ctx, hcp))
}

func proxyFixture(params ProxyParams) *hyperv1.HostedControlPlane {
	return &hyperv1.HostedControlPlane{ObjectMeta: metav1.ObjectMeta{Namespace: params.Namespace},
		Spec: hyperv1.HostedControlPlaneSpec{Configuration: &hyperv1.ClusterConfiguration{
			Proxy: &configv1.ProxySpec{TrustedCA: configv1.ConfigMapNameReference{Name: params.TrustedCA}}}}}
}

func ReconcileProxyTrustedCA(ctx context.Context, hosted HostedCluster, cp ControlPlane, params ProxyParams) error {
	return legacyRoot(hosted, cp).reconcileProxyTrustedCAConfigMap(ctx, proxyFixture(params))
}

func ReconcileProxyCABundle(ctx context.Context, hosted HostedCluster, cp ControlPlane, params ProxyParams) error {
	return legacyRoot(hosted, cp).reconcileProxyCABundle(ctx, proxyFixture(params))
}
