# TC-012 result: scale19n1

**Completed with workarounds on 2026-11-19; not a clean pass.** The new Agent `<UUID>` was approved and installed as `worker-3`. Its Ignition proxy override and `ci.openshift.io/hcp-agent-nutanix-run` label match the original three workers. Live checks after cleanup found NodePool `local-cluster/<cluster-id>` at four replicas with `Ready=True`, all four guest Nodes Ready, and the temporary workload namespace and Node labels removed.

## Workload observations

- Baseline: four Ready server Pods across three workers (2/1/1), with two continuous probe Pods on distinct workers.
- Scale-out: four Ready server Pods across four workers (1/1/1/1) after a PDB-respecting eviction; a canary targeted to `worker-3` passed.
- Scale-in: original `worker-2` was selected (Machine `<cluster-id>-4hbht`, Agent `<UUID>`). Its replacement server Pod became Ready in 15 seconds, within the 10-minute requirement.
- Reuse: the same Agent UUID returned as Machine `<cluster-id>-mpxgr` on `worker-2`. After restoring the workload image, a node-targeted canary passed and four Ready server Pods again occupied four distinct workers.
- The Service and all direct Pod identity checks passed in each of the four snapshots: 20 checks total. The continuous recorder captured 3,827 successful samples and zero failed samples from 12:21:00 to 13:24:45 UTC. Its maximum gap between successful samples was 1.893 seconds. This is sampled availability at the configured two-second probe interval, not proof of uninterrupted availability between samples.

## Workarounds and limits

1. This run reproduced both proxy defects in [MGMT-25581](<URL> The standard Agent reclaim DaemonSet omitted proxy environment variables, so the agent could not reach the management Assisted Service route. Adding the guest proxy let it receive a download-boot-artifacts instruction, but the agent's custom-CA HTTP transport lacked `ProxyFromEnvironment` and attempted the artifact download directly. A temporary patched image added `ProxyFromEnvironment` and an additional nil-response guard for the error path; reclaim and reuse then completed. The patch is in `reclaim-fix/download-proxy.patch`; it was not committed to this repository.
2. The guest image registry had one replica backed by `emptyDir`. Its Pod was recreated during scale-in, losing the workload image manifest while the ImageStream retained the old digest. The first canary on the returned worker failed with `manifest unknown`. Republishing the same workload binary at a new digest and updating the workload Deployments restored image pulls; the retried canary passed.
3. Prism VM identity was not independently checked against Agent inventory. The Agent-to-Machine-to-Node relationship is established by cluster objects, but this evidence does not prove which Prism VM produced each Agent.

Evidence: `baseline/`, `scale-out/`, `scale-in/`, `reuse/`, `probe-availability.json`, and `probe-watch/` in this directory. Key machine and node snapshots are in `reuse/`; recovery timing is in `scale-in/workload-recovery.json`.
