# TC-014 HTTP workload run: manual19n1

- Source commit: `9043a0dcdd2c989323c1c81ae0ae20ffd3618986` (clean source).
- Image: `<internal-host>:5000/ocpstrat-2100-tc-014-manual19n1/http-workload@sha256:9017bfb69a6862faf9f6a00754dbf5b3291c2ff8f7df8018f030c01ad9bbae59`.
- Build: Go tests and vet passed. The first in-cluster build could not pull Docker Hub's `golang:1.24` image; the successful build used the locally compiled binary and the scratch final stage from the committed Containerfile.
- Placement: three Ready server Pods on `worker-0`, `worker-1`, and `worker-2`, with three Ready Service endpoints.
- Requests: Service and all three direct Pod `/identity` probes passed; see `request-results.tsv` and `responses/`.
- Management cluster: all three Agents were `added-to-existing-cluster`; three Machines were Running; NodePool `Ready`, `AllMachinesReady`, and `AllNodesHealthy` were True.
- Cleanup: test namespace and all three run-specific Node labels were removed. The manual Prism VMs, Agents, and NodePool were retained.
- Scope: this run verified the HTTP workload and existing cluster membership. It did not repeat manual Prism provisioning or independently verify Prism VM-to-Agent identity.
